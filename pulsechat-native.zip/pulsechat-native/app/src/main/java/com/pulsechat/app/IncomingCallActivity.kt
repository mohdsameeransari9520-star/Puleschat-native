package com.pulsechat.app

import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlin.math.roundToInt

class IncomingCallActivity : ComponentActivity() {

    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var cancelListener: ValueEventListener? = null
    private var activeSessionId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Wake up screen over Lock Screen just like WhatsApp
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            km.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        val callerId = intent.getStringExtra("callerId") ?: ""
        val callerName = intent.getStringExtra("callerName") ?: "Unknown Caller"
        val callType = intent.getStringExtra("callType") ?: "audio"
        val sessionId = intent.getStringExtra("callSessionId") ?: ""
        activeSessionId = sessionId

        if (intent.getBooleanExtra("action_decline", false)) {
            declineCall(sessionId)
            return
        }

        startRinging()
        watchCallerHangup(sessionId)

        setContent {
            AnimatedIncomingCallScreen(
                callerName = callerName,
                callType = callType,
                onAccept = {
                    stopRinging()
                    cancelCallNotification()
                    val openMain = Intent(this, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        putExtra("accepted_caller_id", callerId)
                        putExtra("accepted_caller_name", callerName)
                        putExtra("accepted_call_type", callType)
                        putExtra("accepted_session_id", sessionId)
                    }
                    startActivity(openMain)
                    finish()
                },
                onDecline = {
                    declineCall(sessionId)
                }
            )
        }
    }

    private fun watchCallerHangup(sessionId: String) {
        if (sessionId.isBlank()) return
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val st = snapshot.getValue(String::class.java)
                if (st == "ended" || st == "declined") {
                    stopRinging()
                    cancelCallNotification()
                    finish()
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        cancelListener = listener
        FirebaseDatabase.getInstance().reference
            .child("calls")
            .child(sessionId)
            .child("status")
            .addValueEventListener(listener)
    }

    private fun startRinging() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(applicationContext, uri)
            ringtone?.play()
        } catch (_: Exception) {}

        try {
            @Suppress("DEPRECATION")
            vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            val pattern = longArrayOf(0, 800, 600)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        } catch (_: Exception) {}
    }

    private fun stopRinging() {
        try { ringtone?.stop() } catch (_: Exception) {}
        try { vibrator?.cancel() } catch (_: Exception) {}
    }

    private fun cancelCallNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.cancel(8888)
    }

    private fun declineCall(sessionId: String) {
        stopRinging()
        cancelCallNotification()
        if (sessionId.isNotBlank()) {
            try {
                FirebaseDatabase.getInstance().reference
                    .child("calls")
                    .child(sessionId)
                    .child("status")
                    .setValue("declined")
            } catch (_: Exception) {}
        }
        finish()
    }

    override fun onDestroy() {
        stopRinging()
        cancelListener?.let {
            if (activeSessionId.isNotBlank()) {
                FirebaseDatabase.getInstance().reference
                    .child("calls")
                    .child(activeSessionId)
                    .child("status")
                    .removeEventListener(it)
            }
        }
        super.onDestroy()
    }
}

@Composable
fun AnimatedIncomingCallScreen(
    callerName: String,
    callType: String,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "incomingCallAnim")

    // Dual Radar Ripple Rings around caller avatar
    val ripple1Scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 2.0f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing)),
        label = "r1s"
    )
    val ripple1Alpha by infiniteTransition.animateFloat(
        initialValue = 0.65f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing)),
        label = "r1a"
    )
    val ripple2Scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 2.0f,
        animationSpec = infiniteRepeatable(tween(1800, delayMillis = 700, easing = FastOutSlowInEasing)),
        label = "r2s"
    )
    val ripple2Alpha by infiniteTransition.animateFloat(
        initialValue = 0.65f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1800, delayMillis = 700, easing = FastOutSlowInEasing)),
        label = "r2a"
    )

    // WhatsApp-style bouncy floating Accept button animation
    val acceptBounce by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -16f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bounce"
    )

    var swipeOffsetY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF062C24), Color(0xFF0B141A), Color(0xFF0B141A))
                )
            )
            .padding(32.dp)
    ) {
        // Top Caller Info + Ripple Animation
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 64.dp)
        ) {
            Text(
                text = if (callType == "video") "PULSECHAT VIDEO CALL" else "PULSECHAT VOICE CALL",
                color = Color(0xFF34D399),
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(42.dp))

            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(150.dp)) {
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .scale(ripple1Scale)
                        .alpha(ripple1Alpha)
                        .clip(CircleShape)
                        .background(Color(0xFF00A884))
                )
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .scale(ripple2Scale)
                        .alpha(ripple2Alpha)
                        .clip(CircleShape)
                        .background(Color(0xFF34D399))
                )
                Box(
                    modifier = Modifier
                        .size(112.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(Color(0xFF00A884), Color(0xFF008069)))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = callerName.firstOrNull()?.uppercase() ?: "U",
                        color = Color.White,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))
            Text(
                text = callerName,
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Ringing...",
                color = Color(0xFF94A3B8),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }

        // Bottom Animated Swipe-Up / Tap Accept & Decline Buttons
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 44.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            // Decline Button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                FloatingActionButton(
                    onClick = onDecline,
                    containerColor = Color(0xFFE11D48),
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(72.dp)
                ) {
                    Icon(Icons.Default.CallEnd, contentDescription = "Decline", modifier = Modifier.size(32.dp))
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("Decline", color = Color(0xFFFDA4AF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            // Animated Swipe-Up OR Tap Accept Button
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragEnd = {
                            if (swipeOffsetY < -90f) onAccept()
                            swipeOffsetY = 0f
                        },
                        onDragCancel = { swipeOffsetY = 0f },
                        onVerticalDrag = { _, dragAmount ->
                            swipeOffsetY = (swipeOffsetY + dragAmount).coerceIn(-160f, 0f)
                        }
                    )
                }
            ) {
                Icon(
                    Icons.Default.KeyboardArrowUp,
                    contentDescription = null,
                    tint = Color(0xFF34D399).copy(alpha = 0.7f),
                    modifier = Modifier
                        .size(28.dp)
                        .offset { IntOffset(0, (acceptBounce * 0.6f).roundToInt()) }
                )
                Spacer(modifier = Modifier.height(4.dp))
                FloatingActionButton(
                    onClick = onAccept,
                    containerColor = Color(0xFF00A884),
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(72.dp)
                        .offset { IntOffset(0, (acceptBounce + swipeOffsetY).roundToInt()) }
                ) {
                    Icon(
                        if (callType == "video") Icons.Default.Videocam else Icons.Default.Call,
                        contentDescription = "Accept",
                        modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("Swipe / Tap", color = Color(0xFF6EE7B7), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
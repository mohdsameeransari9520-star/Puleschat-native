package com.pulsechat.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.google.firebase.database.*
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.SurfaceViewRenderer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

private const val PREFS_NAME = "pulsechat_native_prefs"
private const val PUSH_WORKER_URL = "https://pulsechat-push.mohdsameeransari9520.workers.dev"
private const val FALLBACK_RTDB_URL = "https://pulsechat-46903-default-rtdb.firebaseio.com"

private val mainHandler = Handler(Looper.getMainLooper())

/**
 * Safely returns the FirebaseDatabase instance even if google-services.json
 * was exported before Realtime Database creation (missing firebase_url).
 */
fun getPulseDb(): FirebaseDatabase {
    return try {
        FirebaseDatabase.getInstance()
    } catch (_: Exception) {
        FirebaseDatabase.getInstance(FALLBACK_RTDB_URL)
    }
}

// ==================== DATA MODELS (Firebase No-Arg Compatible) ====================

data class ChatThread(
    val id: String = "",
    val title: String = "",
    val peerId: String = "",
    val isGroup: Boolean = false,
    val lastMessage: String = "",
    val lastTimestamp: Long = 0L,
    val unreadCount: Int = 0
)

data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val msgType: String = "text", // text, photo, audio
    val text: String = "",
    val mediaBase64: String = "",
    val audioBase64: String = "",
    val replyAuthor: String = "",
    val replyPreview: String = "",
    val reaction: String = "",
    val deleted: Boolean = false,
    val status: String = "sent", // sent, delivered, read
    val timestamp: Long = 0L
)

data class ContactItem(
    val peerId: String = "",
    val name: String = ""
)

data class CallLogItem(
    val id: String = "",
    val remoteId: String = "",
    val remoteName: String = "",
    val callType: String = "audio",
    val direction: String = "outgoing",
    val status: String = "Ended",
    val timestamp: Long = 0L
)

data class UserProfileMeta(
    val peerId: String = "",
    val name: String = "",
    val online: Boolean = false,
    val lastSeen: Long = 0L,
    val fcmToken: String = ""
)

data class SavedAccount(
    val name: String,
    val email: String,
    val peerId: String
)

data class ActiveCallSession(
    val sessionId: String,
    val remoteId: String,
    val remoteName: String,
    val callType: String,
    val isCaller: Boolean,
    val status: String
)

data class IncomingCallData(
    val sessionId: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val callType: String = "audio",
    val timestamp: Long = 0L
)

data class AppPalette(
    val name: String,
    val brandPrimary: Color,
    val brandSecondary: Color,
    val bgMain: Color,
    val surfaceCard: Color,
    val surfaceElevated: Color,
    val chatBg: Color,
    val bubbleOut: Color,
    val bubbleOutText: Color,
    val bubbleIn: Color,
    val bubbleInText: Color,
    val textPrimary: Color,
    val textMuted: Color,
    val divider: Color,
    val isDark: Boolean
)

fun getAppPalette(themeKey: String): AppPalette = when (themeKey) {
    "light" -> AppPalette(
        name = "Light",
        brandPrimary = Color(0xFF00A884),
        brandSecondary = Color(0xFF008069),
        bgMain = Color(0xFFF3F5F8),
        surfaceCard = Color(0xFFFFFFFF),
        surfaceElevated = Color(0xFFF8FAFC),
        chatBg = Color(0xFFEFEAE2),
        bubbleOut = Color(0xFFD9FDD3),
        bubbleOutText = Color(0xFF111B21),
        bubbleIn = Color(0xFFFFFFFF),
        bubbleInText = Color(0xFF111B21),
        textPrimary = Color(0xFF111B21),
        textMuted = Color(0xFF667781),
        divider = Color(0xFFE2E8F0),
        isDark = false
    )
    "ocean" -> AppPalette(
        name = "Ocean",
        brandPrimary = Color(0xFF3B82F6),
        brandSecondary = Color(0xFF0284C7),
        bgMain = Color(0xFF071324),
        surfaceCard = Color(0xFF0F213B),
        surfaceElevated = Color(0xFF162C4D),
        chatBg = Color(0xFF060E1C),
        bubbleOut = Color(0xFF1D4ED8),
        bubbleOutText = Color(0xFFFFFFFF),
        bubbleIn = Color(0xFF162742),
        bubbleInText = Color(0xFFF1F5F9),
        textPrimary = Color(0xFFF1F5F9),
        textMuted = Color(0xFF94A3B8),
        divider = Color(0xFF1E3A5F),
        isDark = true
    )
    "violet" -> AppPalette(
        name = "Violet",
        brandPrimary = Color(0xFF8B5CF6),
        brandSecondary = Color(0xFFEC4899),
        bgMain = Color(0xFF0F091A),
        surfaceCard = Color(0xFF1A112B),
        surfaceElevated = Color(0xFF26193E),
        chatBg = Color(0xFF0A0612),
        bubbleOut = Color(0xFF6D28D9),
        bubbleOutText = Color(0xFFFFFFFF),
        bubbleIn = Color(0xFF24173B),
        bubbleInText = Color(0xFFF5F3FF),
        textPrimary = Color(0xFFF5F3FF),
        textMuted = Color(0xFFB4A0E5),
        divider = Color(0xFF31204F),
        isDark = true
    )
    else -> AppPalette(
        name = "Dark",
        brandPrimary = Color(0xFF00A884),
        brandSecondary = Color(0xFF007A63),
        bgMain = Color(0xFF0B141A),
        surfaceCard = Color(0xFF111B21),
        surfaceElevated = Color(0xFF1F2C34),
        chatBg = Color(0xFF0B141A),
        bubbleOut = Color(0xFF005C4B),
        bubbleOutText = Color(0xFFE9EDEF),
        bubbleIn = Color(0xFF202C33),
        bubbleInText = Color(0xFFE9EDEF),
        textPrimary = Color(0xFFE9EDEF),
        textMuted = Color(0xFF8696A0),
        divider = Color(0xFF222E35),
        isDark = true
    )
}

// ==================== MAIN ACTIVITY ====================

class MainActivity : ComponentActivity() {

    private val acceptedCallState = mutableStateOf<ActiveCallSession?>(null)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Enable Firebase offline disk persistence once before any reference call
        try {
            getPulseDb().setPersistenceEnabled(true)
        } catch (_: Exception) {}

        // Synchronous read BEFORE first Compose frame -> 100% Zero-Flash Login
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val initialName = prefs.getString("user_name", "") ?: ""
        val initialEmail = prefs.getString("user_email", "") ?: ""
        val initialPeerId = prefs.getString("peer_id", "") ?: ""
        val initialTheme = prefs.getString("app_theme", "dark") ?: "dark"

        requestRuntimePermissions()
        handleIncomingIntent(intent)

        setContent {
            PulseChatRoot(
                initialName = initialName,
                initialEmail = initialEmail,
                initialPeerId = initialPeerId,
                initialTheme = initialTheme,
                acceptedCall = acceptedCallState.value,
                onClearAcceptedCall = { acceptedCallState.value = null },
                onRequestMediaPermissions = { requestRuntimePermissions() }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val callerId = intent?.getStringExtra("accepted_caller_id") ?: return
        val callerName = intent.getStringExtra("accepted_caller_name") ?: callerId
        val callType = intent.getStringExtra("accepted_call_type") ?: "audio"
        val sessionId = intent.getStringExtra("accepted_session_id") ?: ""

        // Clear intent extras so screen rotations don't re-trigger old calls
        intent.removeExtra("accepted_caller_id")

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val myId = prefs.getString("peer_id", "") ?: ""

        if (sessionId.isNotBlank()) {
            try {
                val db = getPulseDb().reference
                if (myId.isNotBlank()) {
                    db.child("incoming_calls").child(myId).removeValue()
                }
                db.child("calls").child(sessionId).child("status").setValue("connecting")
            } catch (_: Exception) {}
        }

        acceptedCallState.value = ActiveCallSession(
            sessionId = sessionId,
            remoteId = callerId,
            remoteName = callerName,
            callType = callType,
            isCaller = false,
            status = "Connecting..."
        )
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }
}

// ==================== UTILITIES & HELPERS ====================

fun computeFixedPulseId(email: String): String {
    val clean = email.trim().lowercase()
    val rawPrefix = clean.substringBefore("@").filter { it.isLetterOrDigit() }.take(3)
    val prefix = rawPrefix.ifEmpty { "usr" }.padEnd(3, 'x')
    var hash = 2166136261L
    for (ch in clean) {
        hash = hash xor ch.code.toLong()
        hash = (hash * 16777619L) and 0xFFFFFFFFL
    }
    return "pc-$prefix${1000 + (abs(hash) % 9000)}"
}

fun directRoomKey(a: String, b: String): String =
    if (a < b) "dm_${a}_${b}" else "dm_${b}_${a}"

fun formatDateHeader(timestamp: Long): String {
    if (timestamp <= 0L) return ""
    val calMsg = Calendar.getInstance().apply { timeInMillis = timestamp }
    val calNow = Calendar.getInstance()
    val sameYear = calMsg.get(Calendar.YEAR) == calNow.get(Calendar.YEAR)
    val dayDiff = calNow.get(Calendar.DAY_OF_YEAR) - calMsg.get(Calendar.DAY_OF_YEAR)
    return when {
        sameYear && dayDiff == 0 -> "Today"
        sameYear && dayDiff == 1 -> "Yesterday"
        else -> SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(timestamp))
    }
}

fun formatLastSeen(timestamp: Long): String {
    if (timestamp <= 0L) return "offline"
    val diffMs = System.currentTimeMillis() - timestamp
    val mins = diffMs / 60_000L
    return when {
        mins < 1 -> "last seen just now"
        mins < 60 -> "last seen ${mins}m ago"
        else -> "last seen ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(timestamp))}"
    }
}

fun loadSavedAccounts(context: Context): List<SavedAccount> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val raw = prefs.getString("saved_accounts_json", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        val out = mutableListOf<SavedAccount>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            out.add(
                SavedAccount(
                    name = obj.optString("name"),
                    email = obj.optString("email"),
                    peerId = obj.optString("peerId")
                )
            )
        }
        out
    } catch (_: Exception) {
        emptyList()
    }
}

fun persistSavedAccount(context: Context, account: SavedAccount) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val current = loadSavedAccounts(context).filterNot { it.email.equals(account.email, ignoreCase = true) }
    val updated = (listOf(account) + current).take(5)
    val arr = JSONArray()
    updated.forEach { acc ->
        arr.put(
            JSONObject().apply {
                put("name", acc.name)
                put("email", acc.email)
                put("peerId", acc.peerId)
            }
        )
    }
    prefs.edit().putString("saved_accounts_json", arr.toString()).apply()
}

fun sendPushViaWorker(targetToken: String, title: String, body: String, dataMap: Map<String, String>) {
    if (targetToken.isBlank()) return
    CoroutineScope(Dispatchers.IO).launch {
        try {
            val url = URL(PUSH_WORKER_URL)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }
            val dataJson = JSONObject()
            dataMap.forEach { (k, v) -> dataJson.put(k, v) }
            val payload = JSONObject().apply {
                put("token", targetToken)
                put("title", title)
                put("body", body)
                put("data", dataJson)
            }
            OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }
            conn.responseCode
            conn.disconnect()
        } catch (_: Exception) {}
    }
}

suspend fun compressUriToBase64Async(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
    try {
        val stream = context.contentResolver.openInputStream(uri) ?: return@withContext ""
        val original = BitmapFactory.decodeStream(stream)
        stream.close()
        if (original == null) return@withContext ""
        val maxDim = 560
        val scale = minOf(1f, maxDim.toFloat() / maxOf(original.width, original.height))
        val bmp = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                original,
                (original.width * scale).toInt().coerceAtLeast(1),
                (original.height * scale).toInt().coerceAtLeast(1),
                true
            )
        } else original
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 68, out)
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    } catch (_: Exception) {
        ""
    }
}

suspend fun decodeBase64BitmapAsync(b64: String): Bitmap? = withContext(Dispatchers.IO) {
    try {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    } catch (_: Exception) {
        null
    }
}

fun hasCallPermissions(context: Context, isVideo: Boolean): Boolean {
    val hasAudio = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    val hasCamera = !isVideo || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
        PackageManager.PERMISSION_GRANTED
    return hasAudio && hasCamera
}

// ==================== ROOT COMPOSABLE ====================

@Composable
fun PulseChatRoot(
    initialName: String,
    initialEmail: String,
    initialPeerId: String,
    initialTheme: String,
    acceptedCall: ActiveCallSession?,
    onClearAcceptedCall: () -> Unit,
    onRequestMediaPermissions: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }

    var themeKey by remember { mutableStateOf(initialTheme) }
    val palette = remember(themeKey) { getAppPalette(themeKey) }

    var userName by remember { mutableStateOf(initialName) }
    var userEmail by remember { mutableStateOf(initialEmail) }
    var myPeerId by remember { mutableStateOf(initialPeerId) }
    var allowCalls by remember { mutableStateOf(prefs.getBoolean("allow_calls", true)) }
    var readReceipts by remember { mutableStateOf(prefs.getBoolean("read_receipts", true)) }
    var typingIndicators by remember { mutableStateOf(prefs.getBoolean("typing_indicators", true)) }

    val colorScheme = if (palette.isDark) {
        darkColorScheme(
            primary = palette.brandPrimary,
            secondary = palette.brandSecondary,
            background = palette.bgMain,
            surface = palette.surfaceCard,
            surfaceVariant = palette.surfaceElevated,
            onPrimary = Color.White,
            onBackground = palette.textPrimary,
            onSurface = palette.textPrimary
        )
    } else {
        lightColorScheme(
            primary = palette.brandPrimary,
            secondary = palette.brandSecondary,
            background = palette.bgMain,
            surface = palette.surfaceCard,
            surfaceVariant = palette.surfaceElevated,
            onPrimary = Color.White,
            onBackground = palette.textPrimary,
            onSurface = palette.textPrimary
        )
    }

    MaterialTheme(colorScheme = colorScheme) {
        Surface(modifier = Modifier.fillMaxSize(), color = palette.bgMain) {
            if (myPeerId.isBlank()) {
                LoginScreen(
                    palette = palette,
                    onLogin = { name, email ->
                        val id = computeFixedPulseId(email)
                        prefs.edit()
                            .putString("user_name", name)
                            .putString("user_email", email)
                            .putString("peer_id", id)
                            .commit()
                        persistSavedAccount(context, SavedAccount(name, email, id))
                        userName = name
                        userEmail = email
                        myPeerId = id
                    }
                )
            } else {
                PulseChatHome(
                    palette = palette,
                    themeKey = themeKey,
                    onChangeTheme = { newKey ->
                        themeKey = newKey
                        prefs.edit().putString("app_theme", newKey).apply()
                    },
                    userName = userName,
                    userEmail = userEmail,
                    myPeerId = myPeerId,
                    allowCalls = allowCalls,
                    readReceipts = readReceipts,
                    typingIndicators = typingIndicators,
                    onUpdateUserName = { newName ->
                        userName = newName
                        prefs.edit().putString("user_name", newName).apply()
                        persistSavedAccount(context, SavedAccount(newName, userEmail, myPeerId))
                        try {
                            getPulseDb().reference.child("users").child(myPeerId).child("name").setValue(newName)
                        } catch (_: Exception) {}
                    },
                    onToggleAllowCalls = {
                        allowCalls = it
                        prefs.edit().putBoolean("allow_calls", it).apply()
                    },
                    onToggleReadReceipts = {
                        readReceipts = it
                        prefs.edit().putBoolean("read_receipts", it).apply()
                    },
                    onToggleTypingIndicators = {
                        typingIndicators = it
                        prefs.edit().putBoolean("typing_indicators", it).apply()
                    },
                    onLogout = {
                        try {
                            getPulseDb().reference.child("users").child(myPeerId).child("online").setValue(false)
                        } catch (_: Exception) {}
                        prefs.edit()
                            .remove("user_name")
                            .remove("user_email")
                            .remove("peer_id")
                            .commit()
                        myPeerId = ""
                    },
                    acceptedCall = acceptedCall,
                    onClearAcceptedCall = onClearAcceptedCall,
                    onRequestMediaPermissions = onRequestMediaPermissions
                )
            }
        }
    }
}

// ==================== MAIN HOME DASHBOARD ====================

@Composable
fun PulseChatHome(
    palette: AppPalette,
    themeKey: String,
    onChangeTheme: (String) -> Unit,
    userName: String,
    userEmail: String,
    myPeerId: String,
    allowCalls: Boolean,
    readReceipts: Boolean,
    typingIndicators: Boolean,
    onUpdateUserName: (String) -> Unit,
    onToggleAllowCalls: (Boolean) -> Unit,
    onToggleReadReceipts: (Boolean) -> Unit,
    onToggleTypingIndicators: (Boolean) -> Unit,
    onLogout: () -> Unit,
    acceptedCall: ActiveCallSession?,
    onClearAcceptedCall: () -> Unit,
    onRequestMediaPermissions: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }

    var selectedTab by remember { mutableIntStateOf(0) }
    var chatSubTab by remember { mutableIntStateOf(0) }
    var activeChat by remember { mutableStateOf<ChatThread?>(null) }
    var activeCall by remember { mutableStateOf<ActiveCallSession?>(null) }
    var incomingCallData by remember { mutableStateOf<IncomingCallData?>(null) }
    var isFirebaseConnected by remember { mutableStateOf(false) }
    var fcmTokenState by remember { mutableStateOf(prefs.getString("fcm_token", "") ?: "") }

    var threads by remember { mutableStateOf<List<ChatThread>>(emptyList()) }
    var contacts by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    var callLogs by remember { mutableStateOf<List<CallLogItem>>(emptyList()) }
    var usersDirectory by remember { mutableStateOf<Map<String, UserProfileMeta>>(emptyMap()) }

    var showNewChatDialog by remember { mutableStateOf(false) }
    var showContactDialog by remember { mutableStateOf(false) }
    var editingContact by remember { mutableStateOf<ContactItem?>(null) }
    var pendingDeleteThread by remember { mutableStateOf<ChatThread?>(null) }

    // Resolve friendly display name: Saved Contact > Cloud Directory > Fallback
    fun resolveName(peerId: String, fallback: String = ""): String {
        val clean = peerId.trim().lowercase()
        contacts.firstOrNull { it.peerId == clean }?.let { return it.name }
        usersDirectory[clean]?.name?.takeIf { it.isNotBlank() }?.let { return it }
        return fallback.ifBlank { clean.uppercase() }
    }

    // Hardware Back button returns to Chats tab when on another tab
    BackHandler(enabled = activeChat == null && activeCall == null && incomingCallData == null && selectedTab != 0) {
        selectedTab = 0
    }

    // Handle calls accepted from Lock-Screen / Notification
    LaunchedEffect(acceptedCall) {
        if (acceptedCall != null) {
            incomingCallData = null
            if (!hasCallPermissions(context, acceptedCall.callType == "video")) {
                onRequestMediaPermissions()
                Toast.makeText(context, "Grant Mic/Camera permission to connect audio/video", Toast.LENGTH_LONG).show()
            }
            activeCall = acceptedCall.copy(
                remoteName = resolveName(acceptedCall.remoteId, acceptedCall.remoteName)
            )
            val logId = "cl_${System.currentTimeMillis()}"
            try {
                getPulseDb().reference
                    .child("call_logs").child(myPeerId).child(logId)
                    .setValue(
                        CallLogItem(
                            id = logId,
                            remoteId = acceptedCall.remoteId,
                            remoteName = resolveName(acceptedCall.remoteId, acceptedCall.remoteName),
                            callType = acceptedCall.callType,
                            direction = "incoming",
                            status = "Accepted",
                            timestamp = System.currentTimeMillis()
                        )
                    )
            } catch (_: Exception) {}
            onClearAcceptedCall()
        }
    }

    // Presence + FCM Token Registration + Cloud Connection Monitor
    fun syncPresenceAndToken() {
        val db = getPulseDb().reference
        val userRef = db.child("users").child(myPeerId)
        val baseMap = mutableMapOf<String, Any>(
            "peerId" to myPeerId,
            "name" to userName,
            "online" to true,
            "lastSeen" to System.currentTimeMillis()
        )
        if (fcmTokenState.isNotBlank()) {
            baseMap["fcmToken"] = fcmTokenState
        }
        try {
            userRef.updateChildren(baseMap)
            userRef.child("online").onDisconnect().setValue(false)
            userRef.child("lastSeen").onDisconnect().setValue(ServerValue.TIMESTAMP)
        } catch (_: Exception) {}

        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            if (!token.isNullOrBlank()) {
                fcmTokenState = token
                prefs.edit().putString("fcm_token", token).apply()
                try {
                    userRef.child("fcmToken").setValue(token)
                } catch (_: Exception) {}
            }
        }
    }

    LaunchedEffect(myPeerId, userName) {
        syncPresenceAndToken()
    }

    // Realtime Firebase Listeners
    DisposableEffect(myPeerId) {
        val db = getPulseDb().reference

        val connRef = db.child(".info/connected")
        val connListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val connected = s.getValue(Boolean::class.java) == true
                isFirebaseConnected = connected
                if (connected) syncPresenceAndToken()
            }
            override fun onCancelled(e: DatabaseError) {}
        }
        connRef.addValueEventListener(connListener)

        val usersRef = db.child("users")
        val usersListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val map = mutableMapOf<String, UserProfileMeta>()
                snapshot.children.forEach { child ->
                    val meta = child.getValue(UserProfileMeta::class.java)
                    if (meta != null && meta.peerId.isNotBlank()) {
                        map[meta.peerId] = meta
                    }
                }
                usersDirectory = map
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        usersRef.addValueEventListener(usersListener)

        val chatsRef = db.child("user_chats").child(myPeerId)
        val chatsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                threads = snapshot.children.mapNotNull { it.getValue(ChatThread::class.java) }
                    .sortedByDescending { it.lastTimestamp }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        chatsRef.addValueEventListener(chatsListener)

        val contactsRef = db.child("contacts").child(myPeerId)
        val contactsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                contacts = snapshot.children.mapNotNull { it.getValue(ContactItem::class.java) }
                    .sortedBy { it.name.lowercase() }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        contactsRef.addValueEventListener(contactsListener)

        val logsRef = db.child("call_logs").child(myPeerId)
        val logsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                callLogs = snapshot.children.mapNotNull { it.getValue(CallLogItem::class.java) }
                    .sortedByDescending { it.timestamp }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        logsRef.addValueEventListener(logsListener)

        val incomingRef = db.child("incoming_calls").child(myPeerId)
        val incomingListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val inc = snapshot.getValue(IncomingCallData::class.java)
                if (inc == null || inc.sessionId.isBlank()) {
                    incomingCallData = null
                } else {
                    val isFresh = (System.currentTimeMillis() - inc.timestamp) < 55_000L
                    if (allowCalls && activeCall == null && isFresh && inc.callerId != myPeerId) {
                        incomingCallData = inc
                    } else if (!isFresh) {
                        incomingRef.removeValue()
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        incomingRef.addValueEventListener(incomingListener)

        onDispose {
            connRef.removeEventListener(connListener)
            usersRef.removeEventListener(usersListener)
            chatsRef.removeEventListener(chatsListener)
            contactsRef.removeEventListener(contactsListener)
            logsRef.removeEventListener(logsListener)
            incomingRef.removeEventListener(incomingListener)
        }
    }

    /**
     * CRITICAL FIX: Write call metadata using updateChildren() BEFORE opening ActiveCallOverlay
     * so WebRtcCallEngine's SDP offer and ICE candidates are NEVER overwritten!
     */
    fun startOutgoingCall(targetId: String, targetName: String, callType: String) {
        val cleanId = targetId.trim().lowercase()
        if (cleanId.isBlank() || cleanId == myPeerId) {
            Toast.makeText(context, "Enter a valid PulseChat ID", Toast.LENGTH_SHORT).show()
            return
        }
        if (!hasCallPermissions(context, callType == "video")) {
            onRequestMediaPermissions()
            Toast.makeText(context, "Please allow Microphone & Camera permissions", Toast.LENGTH_SHORT).show()
            return
        }

        val resolvedName = resolveName(cleanId, targetName)
        val sessionId = "call_${System.currentTimeMillis()}_${(100..999).random()}"
        val now = System.currentTimeMillis()
        val db = getPulseDb().reference

        // 1. Write metadata using updateChildren FIRST (preserves offer/candidates)
        db.child("calls").child(sessionId).updateChildren(
            mapOf(
                "callerId" to myPeerId,
                "callerName" to userName,
                "calleeId" to cleanId,
                "callType" to callType,
                "status" to "ringing",
                "timestamp" to now
            )
        )

        // 2. Trigger instant in-app ringing on receiver's device
        db.child("incoming_calls").child(cleanId).setValue(
            IncomingCallData(
                sessionId = sessionId,
                callerId = myPeerId,
                callerName = userName,
                callType = callType,
                timestamp = now
            )
        )

        // 3. Log outgoing call
        val logId = "cl_$now"
        db.child("call_logs").child(myPeerId).child(logId).setValue(
            CallLogItem(
                id = logId,
                remoteId = cleanId,
                remoteName = resolvedName,
                callType = callType,
                direction = "outgoing",
                status = "Outgoing",
                timestamp = now
            )
        )

        // 4. Send high-priority FCM push to wake receiver even if app is killed/locked
        val cachedToken = usersDirectory[cleanId]?.fcmToken ?: ""
        if (cachedToken.isNotBlank()) {
            sendPushViaWorker(
                targetToken = cachedToken,
                title = "Incoming ${if (callType == "video") "Video" else "Voice"} Call",
                body = "$userName is calling...",
                dataMap = mapOf(
                    "type" to "call",
                    "callerId" to myPeerId,
                    "callerName" to userName,
                    "callType" to callType,
                    "callSessionId" to sessionId
                )
            )
        } else {
            db.child("users").child(cleanId).child("fcmToken").get().addOnSuccessListener { snap ->
                val token = snap.getValue(String::class.java) ?: ""
                if (token.isNotBlank()) {
                    sendPushViaWorker(
                        targetToken = token,
                        title = "Incoming ${if (callType == "video") "Video" else "Voice"} Call",
                        body = "$userName is calling...",
                        dataMap = mapOf(
                            "type" to "call",
                            "callerId" to myPeerId,
                            "callerName" to userName,
                            "callType" to callType,
                            "callSessionId" to sessionId
                        )
                    )
                }
            }
        }

        // 5. Launch ActiveCallOverlay -> starts WebRtcCallEngine cleanly
        activeCall = ActiveCallSession(
            sessionId = sessionId,
            remoteId = cleanId,
            remoteName = resolvedName,
            callType = callType,
            isCaller = true,
            status = "Ringing..."
        )
    }

    // ==================== LAYER 1: IN-APP ANIMATED INCOMING CALL ====================
    if (incomingCallData != null && activeCall == null) {
        val inc = incomingCallData!!
        val callerDisplay = resolveName(inc.callerId, inc.callerName)
        var ringtone by remember(inc.sessionId) { mutableStateOf<Ringtone?>(null) }

        DisposableEffect(inc.sessionId) {
            try {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ringtone = RingtoneManager.getRingtone(context, uri)
                ringtone?.play()
            } catch (_: Exception) {}

            // Auto-dismiss if caller cancels before we pick up
            val statusRef = getPulseDb().reference.child("calls").child(inc.sessionId).child("status")
            val statusListener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val st = snapshot.getValue(String::class.java)
                    if (st == "ended" || st == "declined") {
                        incomingCallData = null
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            }
            statusRef.addValueEventListener(statusListener)

            onDispose {
                try { ringtone?.stop() } catch (_: Exception) {}
                statusRef.removeEventListener(statusListener)
            }
        }

        AnimatedIncomingCallScreen(
            callerName = callerDisplay,
            callType = inc.callType,
            onAccept = {
                try { ringtone?.stop() } catch (_: Exception) {}
                if (!hasCallPermissions(context, inc.callType == "video")) {
                    onRequestMediaPermissions()
                    Toast.makeText(context, "Grant Mic/Camera permission to answer", Toast.LENGTH_SHORT).show()
                }
                val db = getPulseDb().reference
                db.child("incoming_calls").child(myPeerId).removeValue()
                db.child("calls").child(inc.sessionId).child("status").setValue("connecting")

                val logId = "cl_${System.currentTimeMillis()}"
                db.child("call_logs").child(myPeerId).child(logId).setValue(
                    CallLogItem(
                        id = logId,
                        remoteId = inc.callerId,
                        remoteName = callerDisplay,
                        callType = inc.callType,
                        direction = "incoming",
                        status = "Accepted",
                        timestamp = System.currentTimeMillis()
                    )
                )
                incomingCallData = null
                activeCall = ActiveCallSession(
                    sessionId = inc.sessionId,
                    remoteId = inc.callerId,
                    remoteName = callerDisplay,
                    callType = inc.callType,
                    isCaller = false,
                    status = "Connecting..."
                )
            },
            onDecline = {
                try { ringtone?.stop() } catch (_: Exception) {}
                val db = getPulseDb().reference
                db.child("incoming_calls").child(myPeerId).removeValue()
                db.child("calls").child(inc.sessionId).child("status").setValue("declined")
                val logId = "cl_${System.currentTimeMillis()}"
                db.child("call_logs").child(myPeerId).child(logId).setValue(
                    CallLogItem(
                        id = logId,
                        remoteId = inc.callerId,
                        remoteName = callerDisplay,
                        callType = inc.callType,
                        direction = "incoming",
                        status = "Declined",
                        timestamp = System.currentTimeMillis()
                    )
                )
                incomingCallData = null
            }
        )
        return
    }

    // ==================== LAYER 2: ACTIVE WEBRTC AUDIO/VIDEO CALL ====================
    if (activeCall != null) {
        val currentSession = activeCall!!
        ActiveCallOverlay(
            palette = palette,
            call = currentSession,
            onCallStatusChanged = { newStatus ->
                mainHandler.post {
                    val lower = newStatus.lowercase()
                    if (lower == "declined" || lower == "ended") {
                        Toast.makeText(
                            context,
                            if (lower == "declined") "Call declined" else "Call ended",
                            Toast.LENGTH_SHORT
                        ).show()
                        try {
                            getPulseDb().reference.child("incoming_calls").child(currentSession.remoteId).removeValue()
                        } catch (_: Exception) {}
                        activeCall = null
                    } else if (activeCall?.sessionId == currentSession.sessionId) {
                        activeCall = activeCall?.copy(status = newStatus)
                    }
                }
            },
            onHangup = {
                mainHandler.post {
                    try {
                        val db = getPulseDb().reference
                        db.child("incoming_calls").child(currentSession.remoteId).removeValue()
                        if (currentSession.sessionId.isNotBlank()) {
                            db.child("calls").child(currentSession.sessionId).child("status").setValue("ended")
                        }
                    } catch (_: Exception) {}
                    activeCall = null
                }
            }
        )
        return
    }

    // ==================== LAYER 3: CHAT CONVERSATION SCREEN ====================
    if (activeChat != null) {
        val openThread = activeChat!!
        val isSavedContact = !openThread.isGroup && contacts.any { it.peerId == openThread.peerId }
        val resolvedThread = if (!openThread.isGroup) {
            openThread.copy(title = resolveName(openThread.peerId, openThread.title))
        } else openThread

        ChatConversationScreen(
            palette = palette,
            myPeerId = myPeerId,
            myName = userName,
            readReceipts = readReceipts,
            typingIndicators = typingIndicators,
            thread = resolvedThread,
            remoteMeta = if (!openThread.isGroup) usersDirectory[openThread.peerId] else null,
            isSavedContact = isSavedContact,
            onQuickSaveContact = {
                editingContact = ContactItem(peerId = openThread.peerId, name = resolvedThread.title)
                showContactDialog = true
            },
            onBack = { activeChat = null },
            onRequestDelete = { pendingDeleteThread = openThread },
            onStartCall = { type -> startOutgoingCall(openThread.peerId, resolvedThread.title, type) }
        )
    } else {
        // ==================== LAYER 4: 4-TAB DASHBOARD ====================
        val totalUnread = threads.sumOf { it.unreadCount }

        Scaffold(
            containerColor = palette.bgMain,
            topBar = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(palette.brandPrimary, palette.brandSecondary)))
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(13.dp))
                                    .background(Color.White.copy(alpha = 0.22f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(21.dp))
                            }
                            Spacer(modifier = Modifier.width(11.dp))
                            Column {
                                Text("PulseChat", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(if (isFirebaseConnected) Color(0xFF6EE7B7) else Color(0xFFFCD34D))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        if (isFirebaseConnected) "Cloud Online" else "Connecting...",
                                        color = Color.White.copy(alpha = 0.92f),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(
                                onClick = {
                                    val order = listOf("dark", "light", "ocean", "violet")
                                    val next = order[(order.indexOf(themeKey) + 1) % order.size]
                                    onChangeTheme(next)
                                    Toast.makeText(context, "Theme: ${next.replaceFirstChar { it.uppercase() }}", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(Color.White.copy(alpha = 0.18f))
                            ) {
                                Icon(Icons.Default.Palette, contentDescription = "Theme", tint = Color.White, modifier = Modifier.size(18.dp))
                            }

                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(Color.Black.copy(alpha = 0.24f))
                                    .clickable {
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        cm.setPrimaryClip(ClipData.newPlainText("PulseChat ID", myPeerId))
                                        Toast.makeText(context, "ID Copied: $myPeerId", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(myPeerId.uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            floatingActionButton = {
                if (selectedTab == 0 || selectedTab == 1) {
                    FloatingActionButton(
                        onClick = {
                            if (selectedTab == 0) showNewChatDialog = true
                            else {
                                editingContact = null
                                showContactDialog = true
                            }
                        },
                        containerColor = palette.brandPrimary,
                        contentColor = Color.White,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.shadow(8.dp, RoundedCornerShape(18.dp))
                    ) {
                        Icon(
                            when {
                                selectedTab == 1 -> Icons.Default.PersonAdd
                                chatSubTab == 1 -> Icons.Default.GroupAdd
                                else -> Icons.Default.Add
                            },
                            contentDescription = "Create New"
                        )
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = palette.surfaceCard,
                    tonalElevation = 4.dp
                ) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (totalUnread > 0) {
                                        Badge(containerColor = Color(0xFFE11D48), contentColor = Color.White) {
                                            Text(if (totalUnread > 99) "99+" else "$totalUnread", fontSize = 9.sp)
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = "Chats")
                            }
                        },
                        label = { Text("Chats", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Contacts, contentDescription = "Contacts") },
                        label = { Text("Contacts", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Call, contentDescription = "Calls") },
                        label = { Text("Calls", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(palette.bgMain)
                    .padding(padding)
            ) {
                when (selectedTab) {
                    0 -> ChatsTabContent(
                        palette = palette,
                        threads = threads,
                        usersDirectory = usersDirectory,
                        resolveName = { id, fb -> resolveName(id, fb) },
                        subTab = chatSubTab,
                        onSubTabChange = { chatSubTab = it },
                        onOpenChat = { thread ->
                            if (thread.unreadCount > 0) {
                                try {
                                    getPulseDb().reference
                                        .child("user_chats").child(myPeerId).child(thread.id)
                                        .child("unreadCount").setValue(0)
                                } catch (_: Exception) {}
                            }
                            activeChat = thread.copy(unreadCount = 0)
                        },
                        onDeleteThread = { pendingDeleteThread = it }
                    )
                    1 -> ContactsTabContent(
                        palette = palette,
                        contacts = contacts,
                        usersDirectory = usersDirectory,
                        onChat = { c ->
                            val tid = directRoomKey(myPeerId, c.peerId)
                            val existing = threads.firstOrNull { it.id == tid }
                            val t = existing?.copy(title = c.name)
                                ?: ChatThread(tid, c.name, c.peerId, false, "", System.currentTimeMillis(), 0)
                            try {
                                getPulseDb().reference.child("user_chats").child(myPeerId).child(tid).setValue(t)
                            } catch (_: Exception) {}
                            activeChat = t
                        },
                        onCall = { c, type -> startOutgoingCall(c.peerId, c.name, type) },
                        onEdit = { c ->
                            editingContact = c
                            showContactDialog = true
                        },
                        onDelete = { c ->
                            try {
                                getPulseDb().reference.child("contacts").child(myPeerId).child(c.peerId).removeValue()
                                Toast.makeText(context, "Contact deleted", Toast.LENGTH_SHORT).show()
                            } catch (_: Exception) {}
                        }
                    )
                    2 -> CallsTabContent(
                        palette = palette,
                        callLogs = callLogs,
                        resolveName = { id, fb -> resolveName(id, fb) },
                        onDial = { id, type -> startOutgoingCall(id, resolveName(id), type) },
                        onDeleteLog = { log ->
                            try {
                                getPulseDb().reference.child("call_logs").child(myPeerId).child(log.id).removeValue()
                            } catch (_: Exception) {}
                        },
                        onClearAll = {
                            try {
                                getPulseDb().reference.child("call_logs").child(myPeerId).removeValue()
                                Toast.makeText(context, "Call history cleared", Toast.LENGTH_SHORT).show()
                            } catch (_: Exception) {}
                        }
                    )
                    3 -> SettingsTabContent(
                        palette = palette,
                        themeKey = themeKey,
                        userName = userName,
                        userEmail = userEmail,
                        myPeerId = myPeerId,
                        isFirebaseConnected = isFirebaseConnected,
                        hasFcmToken = fcmTokenState.isNotBlank(),
                        allowCalls = allowCalls,
                        readReceipts = readReceipts,
                        typingIndicators = typingIndicators,
                        onUpdateName = onUpdateUserName,
                        onChangeTheme = onChangeTheme,
                        onRetrySync = {
                            syncPresenceAndToken()
                            Toast.makeText(context, "Cloud & Push sync refreshed", Toast.LENGTH_SHORT).show()
                        },
                        onToggleAllowCalls = onToggleAllowCalls,
                        onToggleReadReceipts = onToggleReadReceipts,
                        onToggleTypingIndicators = onToggleTypingIndicators,
                        onLogout = onLogout
                    )
                }
            }
        }
    }

    // ==================== DIALOGS ====================

    // New Chat / Create or Join Group Dialog
    if (showNewChatDialog) {
        var inputName by remember { mutableStateOf("") }
        var inputId by remember { mutableStateOf("") }
        val isGroup = chatSubTab == 1

        AlertDialog(
            onDismissRequest = { showNewChatDialog = false },
            containerColor = palette.surfaceCard,
            title = {
                Text(
                    if (isGroup) "Create or Join Group" else "Start New Chat",
                    fontWeight = FontWeight.ExtraBold,
                    color = palette.textPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = inputId,
                        onValueChange = { inputId = it },
                        label = { Text(if (isGroup) "Group Code (e.g. team2026)" else "PulseChat ID (e.g. pc-sam4821)") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = inputName,
                        onValueChange = { inputName = it },
                        label = { Text(if (isGroup) "Group Name" else "Display Name (optional)") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!isGroup && contacts.isNotEmpty()) {
                        Text("Quick Pick from Contacts", color = palette.textMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            contacts.take(4).forEach { c ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(palette.surfaceElevated)
                                        .clickable {
                                            val tid = directRoomKey(myPeerId, c.peerId)
                                            val t = threads.firstOrNull { it.id == tid }
                                                ?: ChatThread(tid, c.name, c.peerId, false, "", System.currentTimeMillis(), 0)
                                            getPulseDb().reference.child("user_chats").child(myPeerId).child(tid).setValue(t)
                                            showNewChatDialog = false
                                            activeChat = t
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(c.name, color = palette.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(c.peerId, color = palette.brandPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clean = inputId.trim().lowercase().replace(" ", "")
                        if (clean.isBlank()) {
                            Toast.makeText(context, "Enter a valid ID", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (!isGroup && clean == myPeerId) {
                            Toast.makeText(context, "You cannot chat with your own ID", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val tid = if (isGroup) "grp_${clean.removePrefix("grp_")}" else directRoomKey(myPeerId, clean)
                        val title = inputName.trim().ifEmpty { resolveName(clean) }
                        val existing = threads.firstOrNull { it.id == tid }
                        val thread = existing?.copy(title = title)
                            ?: ChatThread(tid, title, clean, isGroup, "", System.currentTimeMillis(), 0)
                        getPulseDb().reference.child("user_chats").child(myPeerId).child(tid).setValue(thread)
                        showNewChatDialog = false
                        activeChat = thread
                    },
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Open Chat") }
            },
            dismissButton = {
                TextButton(onClick = { showNewChatDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Add / Edit Contact Dialog
    if (showContactDialog) {
        var cName by remember(editingContact) { mutableStateOf(editingContact?.name ?: "") }
        var cId by remember(editingContact) { mutableStateOf(editingContact?.peerId ?: "") }

        AlertDialog(
            onDismissRequest = { showContactDialog = false },
            containerColor = palette.surfaceCard,
            title = {
                Text(
                    if (editingContact == null) "Save Contact" else "Edit Contact",
                    fontWeight = FontWeight.ExtraBold,
                    color = palette.textPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = cName,
                        onValueChange = { cName = it },
                        label = { Text("Contact Name") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = cId,
                        onValueChange = { cId = it },
                        label = { Text("PulseChat ID (e.g. pc-sam4821)") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cleanId = cId.trim().lowercase().replace(" ", "")
                        val cleanName = cName.trim()
                        if (cleanId.isBlank() || cleanName.isBlank()) {
                            Toast.makeText(context, "Enter both Name and ID", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (cleanId == myPeerId) {
                            Toast.makeText(context, "Cannot add your own ID", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val ref = getPulseDb().reference.child("contacts").child(myPeerId)
                        editingContact?.let { if (it.peerId != cleanId) ref.child(it.peerId).removeValue() }
                        ref.child(cleanId).setValue(ContactItem(cleanId, cleanName))
                        showContactDialog = false
                        Toast.makeText(context, "Contact saved", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showContactDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Delete / Clear Chat or Group Dialog
    if (pendingDeleteThread != null) {
        val t = pendingDeleteThread!!
        AlertDialog(
            onDismissRequest = { pendingDeleteThread = null },
            containerColor = palette.surfaceCard,
            title = {
                Text(
                    if (t.isGroup) "Group: ${t.title}" else "Chat: ${resolveName(t.peerId, t.title)}",
                    fontWeight = FontWeight.ExtraBold,
                    color = palette.textPrimary
                )
            },
            text = {
                Text(
                    "Do you want to clear all messages or remove this ${if (t.isGroup) "group" else "chat"}?",
                    color = palette.textMuted,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = {
                            val db = getPulseDb().reference
                            db.child("messages").child(t.id).removeValue()
                            db.child("user_chats").child(myPeerId).child(t.id).child("lastMessage").setValue("")
                            pendingDeleteThread = null
                            Toast.makeText(context, "Messages cleared", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Clear Messages Only") }

                    Button(
                        onClick = {
                            getPulseDb().reference.child("user_chats").child(myPeerId).child(t.id).removeValue()
                            if (activeChat?.id == t.id) activeChat = null
                            pendingDeleteThread = null
                            Toast.makeText(context, if (t.isGroup) "Group removed" else "Chat deleted", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (t.isGroup) "Leave & Delete Group" else "Delete Chat Completely") }
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteThread = null }) { Text("Cancel") }
            }
        )
    }
}

// ==================== TAB 1: CHATS & GROUPS ====================

@Composable
fun ChatsTabContent(
    palette: AppPalette,
    threads: List<ChatThread>,
    usersDirectory: Map<String, UserProfileMeta>,
    resolveName: (String, String) -> String,
    subTab: Int,
    onSubTabChange: (Int) -> Unit,
    onOpenChat: (ChatThread) -> Unit,
    onDeleteThread: (ChatThread) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val directList = threads.filter { !it.isGroup }
    val groupList = threads.filter { it.isGroup }
    val activeList = (if (subTab == 0) directList else groupList).filter {
        val displayTitle = if (it.isGroup) it.title else resolveName(it.peerId, it.title)
        searchQuery.isBlank() ||
            displayTitle.contains(searchQuery, ignoreCase = true) ||
            it.peerId.contains(searchQuery, ignoreCase = true) ||
            it.lastMessage.contains(searchQuery, ignoreCase = true)
    }
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Segmented Sub-Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surfaceCard)
                .border(1.dp, palette.divider, RoundedCornerShape(16.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("Chats (${directList.size})", "Groups (${groupList.size})").forEachIndexed { idx, label ->
                val active = subTab == idx
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (active) Brush.horizontalGradient(listOf(palette.brandPrimary, palette.brandSecondary))
                            else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                        )
                        .clickable { onSubTabChange(idx) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (active) Color.White else palette.textMuted,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Live Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(if (subTab == 0) "Search chats or IDs..." else "Search groups...", fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )

        if (activeList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(palette.brandPrimary.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (subTab == 0) Icons.Default.Chat else Icons.Default.Groups,
                            contentDescription = null,
                            tint = palette.brandPrimary,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        if (searchQuery.isNotBlank()) "No matching results"
                        else if (subTab == 0) "No chats yet"
                        else "No groups yet",
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        if (subTab == 0) "Tap the + button below to message someone by ID."
                        else "Tap + to create a new group or join an existing Group Code.",
                        color = palette.textMuted,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 84.dp)
            ) {
                items(activeList, key = { it.id }) { thread ->
                    val displayName = if (thread.isGroup) thread.title else resolveName(thread.peerId, thread.title)
                    val isOnline = !thread.isGroup && usersDirectory[thread.peerId]?.online == true

                    Card(
                        colors = CardDefaults.cardColors(containerColor = palette.surfaceCard),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, palette.divider.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                            .clickable { onOpenChat(thread) }
                    ) {
                        Row(
                            modifier = Modifier.padding(13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.size(50.dp)) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .background(
                                            if (thread.isGroup) Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFD97706)))
                                            else Brush.linearGradient(listOf(palette.brandPrimary, palette.brandSecondary))
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (thread.isGroup) {
                                        Icon(Icons.Default.Groups, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                                    } else {
                                        Text(
                                            displayName.firstOrNull()?.uppercase() ?: "U",
                                            color = Color.White,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 19.sp
                                        )
                                    }
                                }
                                if (isOnline) {
                                    Box(
                                        modifier = Modifier
                                            .size(13.dp)
                                            .align(Alignment.BottomEnd)
                                            .clip(CircleShape)
                                            .background(palette.surfaceCard)
                                            .padding(2.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF22C55E))
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        displayName,
                                        color = palette.textPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (thread.lastTimestamp > 0L) {
                                        Text(
                                            timeFmt.format(Date(thread.lastTimestamp)),
                                            color = if (thread.unreadCount > 0) palette.brandPrimary else palette.textMuted,
                                            fontWeight = if (thread.unreadCount > 0) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = thread.lastMessage.ifBlank { if (thread.isGroup) "Group: ${thread.peerId}" else thread.peerId },
                                        color = if (thread.unreadCount > 0) palette.textPrimary else palette.textMuted,
                                        fontWeight = if (thread.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (thread.unreadCount > 0) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .defaultMinSize(minWidth = 21.dp, minHeight = 21.dp)
                                                .clip(CircleShape)
                                                .background(palette.brandPrimary)
                                                .padding(horizontal = 6.dp, vertical = 2.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                if (thread.unreadCount > 99) "99+" else "${thread.unreadCount}",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                        }
                                    }
                                }
                            }

                            IconButton(
                                onClick = { onDeleteThread(thread) },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = palette.textMuted.copy(alpha = 0.75f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== TAB 2: CONTACTS ====================

@Composable
fun ContactsTabContent(
    palette: AppPalette,
    contacts: List<ContactItem>,
    usersDirectory: Map<String, UserProfileMeta>,
    onChat: (ContactItem) -> Unit,
    onCall: (ContactItem, String) -> Unit,
    onEdit: (ContactItem) -> Unit,
    onDelete: (ContactItem) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = contacts.filter {
        it.name.contains(query, ignoreCase = true) || it.peerId.contains(query, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search saved contacts...", fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )

        if (filtered.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Contacts, contentDescription = null, tint = palette.brandPrimary.copy(alpha = 0.55f), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("No contacts saved yet", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Tap + to save a friend's PulseChat ID", color = palette.textMuted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 84.dp)
            ) {
                items(filtered, key = { it.peerId }) { c ->
                    val isOnline = usersDirectory[c.peerId]?.online == true
                    Card(
                        colors = CardDefaults.cardColors(containerColor = palette.surfaceCard),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, palette.divider.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                            .clickable { onChat(c) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.size(46.dp)) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .background(Brush.linearGradient(listOf(palette.brandPrimary, palette.brandSecondary))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(c.name.firstOrNull()?.uppercase() ?: "C", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                }
                                if (isOnline) {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .align(Alignment.BottomEnd)
                                            .clip(CircleShape)
                                            .background(palette.surfaceCard)
                                            .padding(2.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF22C55E))
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(c.name, color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (isOnline) "online • ${c.peerId}" else c.peerId,
                                    color = if (isOnline) Color(0xFF22C55E) else palette.textMuted,
                                    fontSize = 11.sp
                                )
                            }

                            IconButton(onClick = { onCall(c, "audio") }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Default.Call, contentDescription = "Voice Call", tint = palette.brandPrimary, modifier = Modifier.size(19.dp))
                            }
                            IconButton(onClick = { onCall(c, "video") }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = Color(0xFF38BDF8), modifier = Modifier.size(19.dp))
                            }
                            IconButton(onClick = { onEdit(c) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = palette.textMuted, modifier = Modifier.size(17.dp))
                            }
                            IconButton(onClick = { onDelete(c) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFF43F5E), modifier = Modifier.size(17.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== TAB 3: CALLS ====================

@Composable
fun CallsTabContent(
    palette: AppPalette,
    callLogs: List<CallLogItem>,
    resolveName: (String, String) -> String,
    onDial: (String, String) -> Unit,
    onDeleteLog: (CallLogItem) -> Unit,
    onClearAll: () -> Unit
) {
    var dialId by remember { mutableStateOf("") }
    val timeFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surfaceCard),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, palette.divider.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("DIRECT DIALER", color = palette.textMuted, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                OutlinedTextField(
                    value = dialId,
                    onValueChange = { dialId = it },
                    placeholder = { Text("Enter PulseChat ID (e.g. pc-sam4821)", fontSize = 13.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { onDial(dialId, "audio") },
                        modifier = Modifier.weight(1f).height(46.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Voice Call", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onDial(dialId, "video") },
                        modifier = Modifier.weight(1f).height(46.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Video Call", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surfaceCard),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(1.dp, palette.divider.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("RECENT CALLS", color = palette.textMuted, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    if (callLogs.isNotEmpty()) {
                        Text(
                            "Clear All",
                            color = Color(0xFFF43F5E),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onClearAll() }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))

                if (callLogs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = palette.textMuted.copy(alpha = 0.5f), modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("No recent calls", color = palette.textMuted, fontSize = 13.sp)
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(callLogs, key = { it.id }) { log ->
                            val isMissedOrDeclined = log.status.equals("Declined", true) || log.status.equals("Missed", true)
                            val displayName = resolveName(log.remoteId, log.remoteName)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(palette.surfaceElevated.copy(alpha = 0.55f))
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isMissedOrDeclined) Color(0xFFF43F5E).copy(alpha = 0.16f)
                                            else palette.brandPrimary.copy(alpha = 0.16f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        if (log.callType == "video") Icons.Default.Videocam else Icons.Default.Call,
                                        contentDescription = null,
                                        tint = if (isMissedOrDeclined) Color(0xFFF43F5E) else palette.brandPrimary,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(displayName, color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        "${log.status} • ${timeFmt.format(Date(log.timestamp))}",
                                        color = if (isMissedOrDeclined) Color(0xFFF43F5E) else palette.textMuted,
                                        fontSize = 11.sp
                                    )
                                }
                                IconButton(onClick = { onDial(log.remoteId, log.callType) }, modifier = Modifier.size(36.dp)) {
                                    Icon(
                                        if (log.callType == "video") Icons.Default.Videocam else Icons.Default.Call,
                                        contentDescription = "Redial",
                                        tint = palette.brandPrimary,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                                IconButton(onClick = { onDeleteLog(log) }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = palette.textMuted, modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== TAB 4: SETTINGS & DIAGNOSTICS ====================

@Composable
fun SettingsTabContent(
    palette: AppPalette,
    themeKey: String,
    userName: String,
    userEmail: String,
    myPeerId: String,
    isFirebaseConnected: Boolean,
    hasFcmToken: Boolean,
    allowCalls: Boolean,
    readReceipts: Boolean,
    typingIndicators: Boolean,
    onUpdateName: (String) -> Unit,
    onChangeTheme: (String) -> Unit,
    onRetrySync: () -> Unit,
    onToggleAllowCalls: (Boolean) -> Unit,
    onToggleReadReceipts: (Boolean) -> Unit,
    onToggleTypingIndicators: (Boolean) -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var showEditNameDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Profile Card
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surfaceCard),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, palette.divider.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Brush.linearGradient(listOf(palette.brandPrimary, palette.brandSecondary))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(userName.firstOrNull()?.uppercase() ?: "U", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(userName, color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        Text(userEmail, color = palette.textMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(modifier = Modifier.height(3.dp))
                        Text("ID: $myPeerId", color = palette.brandPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { showEditNameDialog = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Name", tint = palette.brandPrimary)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("PulseChat ID", myPeerId))
                            Toast.makeText(context, "Copied: $myPeerId", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy ID", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "Add me on PulseChat! My permanent ID is: $myPeerId")
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share PulseChat ID"))
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share ID", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Cloud & Push Diagnostics Card
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surfaceCard),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, palette.divider.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CONNECTION HEALTH", color = palette.textMuted, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    TextButton(onClick = onRetrySync, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sync Now", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Firebase Realtime Cloud", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text(
                        if (isFirebaseConnected) "Connected" else "Offline",
                        color = if (isFirebaseConnected) Color(0xFF22C55E) else Color(0xFFF59E0B),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Background Call Push (FCM)", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text(
                        if (hasFcmToken) "Active" else "Waiting...",
                        color = if (hasFcmToken) Color(0xFF22C55E) else Color(0xFFF59E0B),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        // Appearance Theme Picker
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surfaceCard),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, palette.divider.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("APPEARANCE", color = palette.textMuted, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf(
                        Triple("dark", "Dark", Color(0xFF111B21)),
                        Triple("light", "Light", Color(0xFFFFFFFF)),
                        Triple("ocean", "Ocean", Color(0xFF2563EB)),
                        Triple("violet", "Violet", Color(0xFF8B5CF6))
                    ).forEach { (key, label, swatch) ->
                        val selected = themeKey == key
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (selected) palette.brandPrimary.copy(alpha = 0.14f) else Color.Transparent)
                                .border(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) palette.brandPrimary else palette.divider,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { onChangeTheme(key) }
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(swatch)
                                    .border(1.5.dp, palette.brandPrimary, CircleShape)
                            )
                            Spacer(modifier = Modifier.height(5.dp))
                            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                        }
                    }
                }
            }
        }

        // Privacy & Controls Card
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surfaceCard),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, palette.divider.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("PRIVACY & CALLS", color = palette.textMuted, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Allow Incoming Calls", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Ring & wake screen on calls", color = palette.textMuted, fontSize = 11.sp)
                    }
                    Switch(checked = allowCalls, onCheckedChange = onToggleAllowCalls)
                }
                HorizontalDivider(color = palette.divider)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Read Receipts", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Show blue double ticks", color = palette.textMuted, fontSize = 11.sp)
                    }
                    Switch(checked = readReceipts, onCheckedChange = onToggleReadReceipts)
                }
                HorizontalDivider(color = palette.divider)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Typing Indicator", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Show when you are typing", color = palette.textMuted, fontSize = 11.sp)
                    }
                    Switch(checked = typingIndicators, onCheckedChange = onToggleTypingIndicators)
                }
            }
        }

        Button(
            onClick = onLogout,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Logout", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))
    }

    if (showEditNameDialog) {
        var newName by remember { mutableStateOf(userName) }
        AlertDialog(
            onDismissRequest = { showEditNameDialog = false },
            containerColor = palette.surfaceCard,
            title = { Text("Update Display Name", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Your Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newName.trim().isNotBlank()) {
                        onUpdateName(newName.trim())
                        showEditNameDialog = false
                        Toast.makeText(context, "Name updated", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showEditNameDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ==================== CHAT CONVERSATION SCREEN ====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatConversationScreen(
    palette: AppPalette,
    myPeerId: String,
    myName: String,
    readReceipts: Boolean,
    typingIndicators: Boolean,
    thread: ChatThread,
    remoteMeta: UserProfileMeta?,
    isSavedContact: Boolean,
    onQuickSaveContact: () -> Unit,
    onBack: () -> Unit,
    onRequestDelete: () -> Unit,
    onStartCall: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var draftText by remember { mutableStateOf("") }
    var replyTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var actionMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var lightboxBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isUploadingPhoto by remember { mutableStateOf(false) }

    var isRemoteTyping by remember { mutableStateOf(false) }
    var isRecording by remember { mutableStateOf(false) }
    var recSeconds by remember { mutableIntStateOf(0) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var voiceFile by remember { mutableStateOf<File?>(null) }
    var playingMsgId by remember { mutableStateOf<String?>(null) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    val listState = rememberLazyListState()
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }

    // Hardware Back button handles nested modals first, then returns to chat list
    BackHandler {
        when {
            lightboxBitmap != null -> lightboxBitmap = null
            actionMessage != null -> actionMessage = null
            else -> onBack()
        }
    }

    // Auto-reset typing status after 2.5s of inactivity
    LaunchedEffect(draftText) {
        if (!thread.isGroup && typingIndicators) {
            val typingRef = getPulseDb().reference.child("typing").child(thread.id).child(myPeerId)
            if (draftText.isNotBlank()) {
                typingRef.setValue(true)
                delay(2500)
                typingRef.setValue(false)
            } else {
                typingRef.setValue(false)
            }
        }
    }

    fun sendMsgToFirebase(msgType: String, text: String = "", mediaB64: String = "", audioB64: String = "") {
        val now = System.currentTimeMillis()
        val msgId = "m_${now}_${(100..999).random()}"
        val currentReply = replyTarget
        val msg = ChatMessage(
            id = msgId,
            senderId = myPeerId,
            senderName = myName,
            msgType = msgType,
            text = text,
            mediaBase64 = mediaB64,
            audioBase64 = audioB64,
            replyAuthor = currentReply?.let { if (it.senderId == myPeerId) "You" else it.senderName } ?: "",
            replyPreview = currentReply?.let {
                when (it.msgType) {
                    "photo" -> "📷 Photo"
                    "audio" -> "🎤 Voice message"
                    else -> it.text.take(65)
                }
            } ?: "",
            status = "sent",
            timestamp = now
        )

        // Optimistic UI update (deduplicated)
        messages = (messages + msg).distinctBy { it.id }
        replyTarget = null

        val previewLabel = when (msgType) {
            "photo" -> "📷 Photo"
            "audio" -> "🎤 Voice message"
            else -> text
        }

        val db = getPulseDb().reference
        db.child("messages").child(thread.id).child(msgId).setValue(msg)
            .addOnFailureListener {
                Toast.makeText(context, "Cloud write failed: Check Firebase Realtime DB Rules", Toast.LENGTH_LONG).show()
            }

        db.child("user_chats").child(myPeerId).child(thread.id)
            .setValue(thread.copy(lastMessage = previewLabel, lastTimestamp = now, unreadCount = 0))

        if (!thread.isGroup) {
            val peerChatRef = db.child("user_chats").child(thread.peerId).child(thread.id)
            peerChatRef.child("unreadCount").get().addOnSuccessListener { snap ->
                val prevUnread = snap.getValue(Int::class.java) ?: 0
                peerChatRef.setValue(
                    ChatThread(
                        id = thread.id,
                        title = myName,
                        peerId = myPeerId,
                        isGroup = false,
                        lastMessage = previewLabel,
                        lastTimestamp = now,
                        unreadCount = prevUnread + 1
                    )
                )
            }.addOnFailureListener {
                peerChatRef.setValue(
                    ChatThread(thread.id, myName, myPeerId, false, previewLabel, now, 1)
                )
            }

            db.child("typing").child(thread.id).child(myPeerId).setValue(false)

            val token = remoteMeta?.fcmToken ?: ""
            if (token.isNotBlank()) {
                sendPushViaWorker(token, myName, previewLabel, mapOf("type" to "message"))
            } else {
                db.child("users").child(thread.peerId).child("fcmToken").get().addOnSuccessListener { snap ->
                    val fetched = snap.getValue(String::class.java) ?: ""
                    if (fetched.isNotBlank()) {
                        sendPushViaWorker(fetched, myName, previewLabel, mapOf("type" to "message"))
                    }
                }
            }
        }
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                isUploadingPhoto = true
                val b64 = compressUriToBase64Async(context, uri)
                isUploadingPhoto = false
                if (b64.isNotBlank()) {
                    sendMsgToFirebase(msgType = "photo", mediaB64 = b64)
                } else {
                    Toast.makeText(context, "Could not process photo", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Stop voice recording automatically at 25s
    LaunchedEffect(isRecording) {
        if (isRecording) {
            recSeconds = 0
            while (isRecording && recSeconds < 25) {
                delay(1000)
                recSeconds++
            }
            if (isRecording) {
                isRecording = false
                try {
                    recorder?.stop()
                    recorder?.release()
                    recorder = null
                    voiceFile?.let { f ->
                        if (f.exists() && f.length() > 100) {
                            val b64 = withContext(Dispatchers.IO) {
                                Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
                            }
                            sendMsgToFirebase(msgType = "audio", audioB64 = b64)
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    // Firebase Message & Typing Listeners
    DisposableEffect(thread.id) {
        val db = getPulseDb().reference
        val msgRef = db.child("messages").child(thread.id)

        val msgListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = snapshot.children.mapNotNull { it.getValue(ChatMessage::class.java) }
                    .sortedBy { it.timestamp }
                messages = list

                // Mark unread incoming messages as read / delivered
                if (!thread.isGroup) {
                    val targetStatus = if (readReceipts) "read" else "delivered"
                    list.filter { it.senderId != myPeerId && it.status != targetStatus && it.status != "read" }
                        .forEach { unread ->
                            msgRef.child(unread.id).child("status").setValue(targetStatus)
                        }
                    db.child("user_chats").child(myPeerId).child(thread.id).child("unreadCount").setValue(0)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        msgRef.addValueEventListener(msgListener)

        var typingRef: DatabaseReference? = null
        var typingListener: ValueEventListener? = null
        if (!thread.isGroup) {
            typingRef = db.child("typing").child(thread.id).child(thread.peerId)
            typingListener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    isRemoteTyping = s.getValue(Boolean::class.java) == true
                }
                override fun onCancelled(e: DatabaseError) {}
            }
            typingRef.addValueEventListener(typingListener)
        }

        onDispose {
            msgRef.removeEventListener(msgListener)
            if (typingRef != null && typingListener != null) typingRef.removeEventListener(typingListener)
            if (!thread.isGroup) {
                try { db.child("typing").child(thread.id).child(myPeerId).setValue(false) } catch (_: Exception) {}
            }
            try { recorder?.release() } catch (_: Exception) {}
            try { mediaPlayer?.release() } catch (_: Exception) {}
        }
    }

    LaunchedEffect(messages.size, isRemoteTyping) {
        val totalItems = messages.size + if (isRemoteTyping) 1 else 0
        if (totalItems > 0) {
            listState.animateScrollToItem(totalItems - 1)
        }
    }

    Scaffold(
        containerColor = palette.chatBg,
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.22f)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (thread.isGroup) {
                                Icon(Icons.Default.Groups, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                            } else {
                                Text(thread.title.firstOrNull()?.uppercase() ?: "U", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(thread.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                text = when {
                                    thread.isGroup -> "Group ID: ${thread.peerId}"
                                    isRemoteTyping -> "typing..."
                                    remoteMeta?.online == true -> "online"
                                    remoteMeta != null && remoteMeta.lastSeen > 0L -> formatLastSeen(remoteMeta.lastSeen)
                                    else -> thread.peerId
                                },
                                color = if (isRemoteTyping || remoteMeta?.online == true) Color(0xFFA7F3D0) else Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp,
                                fontWeight = if (isRemoteTyping) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                },
                actions = {
                    if (thread.isGroup) {
                        IconButton(onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("Group ID", thread.peerId))
                            Toast.makeText(context, "Group ID copied: ${thread.peerId}", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Group ID", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    } else {
                        if (!isSavedContact) {
                            IconButton(onClick = onQuickSaveContact) {
                                Icon(Icons.Default.PersonAdd, contentDescription = "Save Contact", tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        }
                        IconButton(onClick = { onStartCall("audio") }) {
                            Icon(Icons.Default.Call, contentDescription = "Voice Call", tint = Color.White)
                        }
                        IconButton(onClick = { onStartCall("video") }) {
                            Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = Color.White)
                        }
                    }
                    IconButton(onClick = onRequestDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = palette.brandSecondary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(palette.chatBg)
                .padding(padding)
                .imePadding()
        ) {
            // Message Feed
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                itemsIndexed(messages, key = { _, m -> m.id }) { index, msg ->
                    val currentDateLabel = formatDateHeader(msg.timestamp)
                    val prevDateLabel = if (index > 0) formatDateHeader(messages[index - 1].timestamp) else ""

                    if (currentDateLabel.isNotBlank() && currentDateLabel != prevDateLabel) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = currentDateLabel,
                                color = palette.textMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.surfaceCard.copy(alpha = 0.88f))
                                    .padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                    }

                    val isMe = msg.senderId == myPeerId
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                    ) {
                        Column(
                            modifier = Modifier
                                .widthIn(min = 84.dp, max = 290.dp)
                                .clip(
                                    RoundedCornerShape(
                                        topStart = 18.dp,
                                        topEnd = 18.dp,
                                        bottomStart = if (isMe) 18.dp else 4.dp,
                                        bottomEnd = if (isMe) 4.dp else 18.dp
                                    )
                                )
                                .background(if (isMe) palette.bubbleOut else palette.bubbleIn)
                                .clickable { if (!msg.deleted) actionMessage = msg }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            if (!isMe && thread.isGroup) {
                                Text(
                                    msg.senderName,
                                    color = palette.brandPrimary,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(bottom = 2.dp)
                                )
                            }

                            if (msg.replyPreview.isNotBlank() && !msg.deleted) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 6.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color.Black.copy(alpha = if (palette.isDark) 0.22f else 0.08f))
                                        .padding(horizontal = 9.dp, vertical = 5.dp)
                                ) {
                                    Text(msg.replyAuthor, color = palette.brandPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    Text(
                                        msg.replyPreview,
                                        color = (if (isMe) palette.bubbleOutText else palette.bubbleInText).copy(alpha = 0.8f),
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            val bubbleTextColor = if (isMe) palette.bubbleOutText else palette.bubbleInText

                            when {
                                msg.deleted -> {
                                    Text(
                                        "🚫 This message was deleted",
                                        color = palette.textMuted,
                                        fontSize = 12.sp,
                                        fontStyle = FontStyle.Italic
                                    )
                                }
                                msg.msgType == "photo" && msg.mediaBase64.isNotBlank() -> {
                                    val bmp by produceState<Bitmap?>(initialValue = null, key1 = msg.mediaBase64) {
                                        value = decodeBase64BitmapAsync(msg.mediaBase64)
                                    }
                                    if (bmp != null) {
                                        Image(
                                            bitmap = bmp!!.asImageBitmap(),
                                            contentDescription = "Photo",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(195.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .clickable { lightboxBitmap = bmp }
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(140.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(Color.Black.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                                        }
                                    }
                                }
                                msg.msgType == "audio" && msg.audioBase64.isNotBlank() -> {
                                    val isPlaying = playingMsgId == msg.id
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    ) {
                                        IconButton(
                                            onClick = {
                                                if (isPlaying) {
                                                    try { mediaPlayer?.stop(); mediaPlayer?.release() } catch (_: Exception) {}
                                                    mediaPlayer = null
                                                    playingMsgId = null
                                                } else {
                                                    scope.launch {
                                                        try {
                                                            mediaPlayer?.release()
                                                            val tmp = withContext(Dispatchers.IO) {
                                                                val f = File(context.cacheDir, "play_${msg.id}.m4a")
                                                                FileOutputStream(f).use {
                                                                    it.write(Base64.decode(msg.audioBase64, Base64.DEFAULT))
                                                                }
                                                                f
                                                            }
                                                            mediaPlayer = MediaPlayer().apply {
                                                                setDataSource(tmp.absolutePath)
                                                                prepare()
                                                                start()
                                                                setOnCompletionListener { playingMsgId = null }
                                                            }
                                                            playingMsgId = msg.id
                                                        } catch (_: Exception) {
                                                            Toast.makeText(context, "Unable to play voice note", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                }
                                            },
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(palette.brandPrimary)
                                        ) {
                                            Icon(
                                                if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                                contentDescription = "Play Voice Note",
                                                tint = Color.White
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                if (isPlaying) "Playing voice note..." else "Voice Message",
                                                color = bubbleTextColor,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                if (isPlaying) "Tap stop to pause" else "Tap play to listen",
                                                color = bubbleTextColor.copy(alpha = 0.65f),
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                                else -> {
                                    Text(msg.text, color = bubbleTextColor, fontSize = 14.sp, lineHeight = 20.sp)
                                }
                            }

                            Row(
                                modifier = Modifier.align(Alignment.End).padding(top = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (msg.reaction.isNotBlank()) {
                                    Text(
                                        msg.reaction,
                                        fontSize = 13.sp,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color.Black.copy(alpha = 0.16f))
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                                Text(
                                    timeFmt.format(Date(msg.timestamp)),
                                    fontSize = 10.sp,
                                    color = bubbleTextColor.copy(alpha = 0.65f)
                                )
                                if (isMe) {
                                    Icon(
                                        imageVector = if (msg.status == "sent") Icons.Default.Done else Icons.Default.DoneAll,
                                        contentDescription = null,
                                        tint = if (msg.status == "read") Color(0xFF38BDF8) else bubbleTextColor.copy(alpha = 0.65f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Live Animated Typing Bubble
                if (isRemoteTyping) {
                    item(key = "typing_indicator") {
                        TypingIndicatorBubble(palette = palette)
                    }
                }
            }

            // Photo Upload Progress Bar
            AnimatedVisibility(visible = isUploadingPhoto) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = palette.brandPrimary
                )
            }

            // Reply Preview Bar
            AnimatedVisibility(
                visible = replyTarget != null,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                replyTarget?.let { rt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(palette.surfaceCard)
                            .border(1.dp, palette.divider)
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(32.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(palette.brandPrimary)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Replying to ${if (rt.senderId == myPeerId) "You" else rt.senderName}",
                                color = palette.brandPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                rt.text.ifBlank { if (rt.msgType == "photo") "📷 Photo" else "🎤 Voice message" },
                                color = palette.textMuted,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = { replyTarget = null }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel Reply", tint = palette.textMuted, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // Voice Recording Status Strip
            AnimatedVisibility(visible = isRecording) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFE11D48))
                        .padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "🔴 Recording voice note... 00:${recSeconds.toString().padStart(2, '0')}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        "Cancel",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.25f))
                            .clickable {
                                isRecording = false
                                try { recorder?.stop(); recorder?.release() } catch (_: Exception) {}
                                recorder = null
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            // Bottom Message Composer Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.surfaceCard)
                    .navigationBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { photoPicker.launch("image/*") }) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = "Send Photo", tint = palette.textMuted)
                }
                OutlinedTextField(
                    value = draftText,
                    onValueChange = { draftText = it },
                    placeholder = { Text("Message", fontSize = 14.sp) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            val txt = draftText.trim()
                            if (txt.isNotEmpty()) {
                                draftText = ""
                                sendMsgToFirebase(msgType = "text", text = txt)
                            }
                        }
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = {
                        if (isRecording) {
                            isRecording = false
                            scope.launch {
                                try {
                                    recorder?.stop()
                                    recorder?.release()
                                    recorder = null
                                    voiceFile?.let { f ->
                                        if (f.exists() && f.length() > 100) {
                                            val b64 = withContext(Dispatchers.IO) {
                                                Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
                                            }
                                            sendMsgToFirebase(msgType = "audio", audioB64 = b64)
                                        }
                                    }
                                } catch (_: Exception) {}
                            }
                        } else {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                Toast.makeText(context, "Microphone permission required", Toast.LENGTH_SHORT).show()
                                return@IconButton
                            }
                            try {
                                val outFile = File(context.cacheDir, "vn_${System.currentTimeMillis()}.m4a")
                                val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context)
                                else @Suppress("DEPRECATION") MediaRecorder()
                                mr.setAudioSource(MediaRecorder.AudioSource.MIC)
                                mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                                mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                                mr.setOutputFile(outFile.absolutePath)
                                mr.prepare()
                                mr.start()
                                voiceFile = outFile
                                recorder = mr
                                isRecording = true
                            } catch (_: Exception) {
                                Toast.makeText(context, "Could not start voice recorder", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isRecording) Color(0xFFE11D48) else palette.brandPrimary.copy(alpha = 0.16f))
                ) {
                    Icon(
                        if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Voice Note",
                        tint = if (isRecording) Color.White else palette.brandPrimary
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                FloatingActionButton(
                    onClick = {
                        val txt = draftText.trim()
                        if (txt.isNotEmpty()) {
                            draftText = ""
                            sendMsgToFirebase(msgType = "text", text = txt)
                        }
                    },
                    containerColor = palette.brandPrimary,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(46.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", modifier = Modifier.size(20.dp))
                }
            }
        }
    }

    // Message Action Dialog (React / Reply / Copy / Delete for Everyone)
    if (actionMessage != null) {
        val m = actionMessage!!
        AlertDialog(
            onDismissRequest = { actionMessage = null },
            containerColor = palette.surfaceCard,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("❤️", "👍", "😂", "🔥", "🙏").forEach { emoji ->
                        Text(
                            text = emoji,
                            fontSize = 26.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable {
                                    val nextReaction = if (m.reaction == emoji) "" else emoji
                                    getPulseDb().reference
                                        .child("messages").child(thread.id).child(m.id).child("reaction")
                                        .setValue(nextReaction)
                                    actionMessage = null
                                }
                                .padding(4.dp)
                        )
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { replyTarget = m; actionMessage = null },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Reply, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reply")
                    }
                    if (m.text.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("Message", m.text))
                                Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                                actionMessage = null
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Copy Text")
                        }
                    }
                    if (m.senderId == myPeerId) {
                        Button(
                            onClick = {
                                getPulseDb().reference
                                    .child("messages").child(thread.id).child(m.id)
                                    .updateChildren(
                                        mapOf(
                                            "deleted" to true,
                                            "text" to "",
                                            "mediaBase64" to "",
                                            "audioBase64" to ""
                                        )
                                    )
                                actionMessage = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Delete for Everyone")
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { actionMessage = null }) { Text("Close") }
            }
        )
    }

    // Full-Screen Photo Lightbox
    if (lightboxBitmap != null) {
        Dialog(
            onDismissRequest = { lightboxBitmap = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
                    .clickable { lightboxBitmap = null },
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = lightboxBitmap!!.asImageBitmap(),
                    contentDescription = "Full Photo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                )
                IconButton(
                    onClick = { lightboxBitmap = null },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(16.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.2f))
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun TypingIndicatorBubble(palette: AppPalette) {
    val transition = rememberInfiniteTransition(label = "typingDots")
    val dot1 by transition.animateFloat(
        initialValue = 0f,
        targetValue = -5f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "d1"
    )
    val dot2 by transition.animateFloat(
        initialValue = 0f,
        targetValue = -5f,
        animationSpec = infiniteRepeatable(tween(450, delayMillis = 140), RepeatMode.Reverse),
        label = "d2"
    )
    val dot3 by transition.animateFloat(
        initialValue = 0f,
        targetValue = -5f,
        animationSpec = infiniteRepeatable(tween(450, delayMillis = 280), RepeatMode.Reverse),
        label = "d3"
    )

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp))
            .background(palette.bubbleIn)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        listOf(dot1, dot2, dot3).forEach { y ->
            Box(
                modifier = Modifier
                    .offset(y = y.dp)
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(palette.brandPrimary)
            )
        }
    }
}

// ==================== LOGIN SCREEN (ZERO-FLASH + SAVED ACCOUNTS) ====================

@Composable
fun LoginScreen(palette: AppPalette, onLogin: (String, String) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf("") }
    val savedAccounts = remember { loadSavedAccounts(context) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.bgMain)
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(86.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(palette.brandPrimary, palette.brandSecondary)))
                .shadow(16.dp, RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(44.dp))
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("PulseChat", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = palette.textPrimary)
        Text(
            "Pure Native Kotlin Messenger",
            fontSize = 12.sp,
            color = palette.brandPrimary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(28.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surfaceCard),
            shape = RoundedCornerShape(26.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, palette.divider, RoundedCornerShape(26.dp))
        ) {
            Column(modifier = Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (errorText.isNotBlank()) {
                    Text(
                        errorText,
                        color = Color(0xFFF43F5E),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF43F5E).copy(alpha = 0.14f))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorText = "" },
                    label = { Text("Your Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; errorText = "" },
                    label = { Text("Email Address") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                AnimatedVisibility(visible = email.contains("@") && email.length > 4) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.brandPrimary.copy(alpha = 0.14f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Your Permanent ID", color = palette.textMuted, fontSize = 11.sp)
                        Text(
                            computeFixedPulseId(email).uppercase(),
                            color = palette.brandPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = {
                        val cleanName = name.trim()
                        val cleanEmail = email.trim().lowercase()
                        when {
                            cleanName.length < 2 -> errorText = "Please enter your name (at least 2 letters)."
                            !cleanEmail.contains("@") || !cleanEmail.contains(".") -> errorText = "Please enter a valid email address."
                            else -> onLogin(cleanName, cleanEmail)
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("Continue", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                }

                if (savedAccounts.isNotEmpty()) {
                    HorizontalDivider(color = palette.divider, modifier = Modifier.padding(vertical = 4.dp))
                    Text("QUICK SIGN-IN", color = palette.textMuted, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                    savedAccounts.forEach { acc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(palette.surfaceElevated)
                                .clickable { onLogin(acc.name, acc.email) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(acc.name, color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(acc.email, color = palette.textMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text(acc.peerId, color = palette.brandPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ==================== REAL WEBRTC ACTIVE AUDIO/VIDEO CALL OVERLAY ====================

@Composable
fun ActiveCallOverlay(
    palette: AppPalette,
    call: ActiveCallSession,
    onCallStatusChanged: (String) -> Unit,
    onHangup: () -> Unit
) {
    val context = LocalContext.current
    val isVideo = call.callType == "video"
    var isMuted by remember { mutableStateOf(false) }
    var isSpeaker by remember { mutableStateOf(isVideo) }
    var isCamOff by remember { mutableStateOf(false) }
    var elapsedSeconds by remember { mutableIntStateOf(0) }

    // Prevent accidental back press from dropping an active call
    BackHandler(enabled = true) { }

    val rtcEngine = remember(call.sessionId) {
        WebRtcCallEngine(
            context = context,
            sessionId = call.sessionId,
            isCaller = call.isCaller,
            isVideo = isVideo,
            onStatusChange = { st -> onCallStatusChanged(st) },
            onCallEnded = { onHangup() }
        )
    }

    DisposableEffect(call.sessionId) {
        try {
            rtcEngine.start()
        } catch (_: Exception) {
            onCallStatusChanged("ended")
        }
        onDispose {
            try { rtcEngine.end(notifyRemote = false) } catch (_: Exception) {}
        }
    }

    // 45-second unanswered ring timeout for caller
    LaunchedEffect(call.sessionId, call.status) {
        if (call.isCaller && call.status.equals("Ringing...", ignoreCase = true)) {
            delay(45_000L)
            if (call.status.equals("Ringing...", ignoreCase = true)) {
                mainHandler.post {
                    Toast.makeText(context, "No answer", Toast.LENGTH_SHORT).show()
                }
                try { rtcEngine.end(notifyRemote = true) } catch (_: Exception) {}
                onHangup()
            }
        }
    }

    // Call duration timer once Connected
    LaunchedEffect(call.status) {
        if (call.status.equals("Connected", ignoreCase = true)) {
            while (true) {
                delay(1000)
                elapsedSeconds++
            }
        }
    }

    val pulse = rememberInfiniteTransition(label = "activePulse")
    val scale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.28f,
        animationSpec = infiniteRepeatable(tween(1350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF071A17), Color(0xFF0B141A), Color(0xFF060B0F)))
            )
    ) {
        // Full-Screen Remote Video Surface
        if (isVideo) {
            AndroidView(
                factory = { ctx ->
                    SurfaceViewRenderer(ctx).also { renderer ->
                        rtcEngine.attachRemoteRenderer(renderer)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Caller Name, Avatar & Status
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = if (isVideo && call.status.equals("Connected", true)) 12.dp else 56.dp)
            ) {
                if (!isVideo || !call.status.equals("Connected", true)) {
                    Box(contentAlignment = Alignment.Center) {
                        if (!call.status.equals("Connected", true)) {
                            Box(
                                modifier = Modifier
                                    .size(120.dp)
                                    .scale(scale)
                                    .clip(CircleShape)
                                    .background(palette.brandPrimary.copy(alpha = 0.25f))
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(112.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(palette.brandPrimary, palette.brandSecondary))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                call.remoteName.firstOrNull()?.uppercase() ?: "U",
                                color = Color.White,
                                fontSize = 44.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(22.dp))
                }

                Text(
                    call.remoteName,
                    color = Color.White,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(6.dp))

                val timerText = if (call.status.equals("Connected", true)) {
                    "${(elapsedSeconds / 60).toString().padStart(2, '0')}:${(elapsedSeconds % 60).toString().padStart(2, '0')}"
                } else call.status

                Text(
                    text = "${if (isVideo) "VIDEO" else "VOICE"} • $timerText",
                    color = Color(0xFF6EE7B7),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.4f))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }

            // Bottom Floating Call Controls Dock
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color.Black.copy(alpha = 0.62f))
                    .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(30.dp))
                    .padding(vertical = 14.dp, horizontal = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        isMuted = !isMuted
                        rtcEngine.setMicMuted(isMuted)
                    },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(if (isMuted) Color.White else Color.White.copy(alpha = 0.16f))
                ) {
                    Icon(
                        if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = if (isMuted) Color.Black else Color.White
                    )
                }

                if (isVideo) {
                    IconButton(
                        onClick = {
                            isCamOff = !isCamOff
                            rtcEngine.setCameraOff(isCamOff)
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(if (isCamOff) Color.White else Color.White.copy(alpha = 0.16f))
                    ) {
                        Icon(
                            if (isCamOff) Icons.Default.VideocamOff else Icons.Default.Videocam,
                            contentDescription = "Camera",
                            tint = if (isCamOff) Color.Black else Color.White
                        )
                    }

                    IconButton(
                        onClick = { rtcEngine.switchCamera() },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.16f))
                    ) {
                        Icon(Icons.Default.Cameraswitch, contentDescription = "Switch Camera", tint = Color.White)
                    }
                } else {
                    IconButton(
                        onClick = {
                            isSpeaker = !isSpeaker
                            rtcEngine.setSpeakerOn(isSpeaker)
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(if (isSpeaker) Color.White else Color.White.copy(alpha = 0.16f))
                    ) {
                        Icon(
                            if (isSpeaker) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Speaker",
                            tint = if (isSpeaker) Color.Black else Color.White
                        )
                    }
                }

                FloatingActionButton(
                    onClick = {
                        try { rtcEngine.end(notifyRemote = true) } catch (_: Exception) {}
                        onHangup()
                    },
                    containerColor = Color(0xFFE11D48),
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(62.dp)
                ) {
                    Icon(Icons.Default.CallEnd, contentDescription = "End Call", modifier = Modifier.size(28.dp))
                }
            }
        }

        // Local Self-View PiP Camera Preview
        if (isVideo) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = 18.dp, bottom = 128.dp)
                    .size(width = 106.dp, height = 152.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .border(2.dp, Color.White.copy(alpha = 0.55f), RoundedCornerShape(18.dp))
                    .background(Color.Black)
            ) {
                AndroidView(
                    factory = { ctx ->
                        SurfaceViewRenderer(ctx).also { renderer ->
                            renderer.setZOrderMediaOverlay(true)
                            rtcEngine.attachLocalRenderer(renderer)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
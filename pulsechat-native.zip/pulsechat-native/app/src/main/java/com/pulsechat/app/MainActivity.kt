package com.pulsechat.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.firebase.database.*
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.SurfaceViewRenderer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

private const val PUSH_WORKER_URL = "https://pulsechat-push.mohdsameeransari9520.workers.dev"
private const val PREFS_NAME = "pulsechat_native_v2"

// ==================== DATA MODELS ====================
data class SavedProfile(
    val name: String,
    val email: String,
    val peerId: String,
    val passwordHash: String
)

data class ContactItem(
    val name: String,
    val peerId: String
)

data class CallLogItem(
    val id: String,
    val name: String,
    val peerId: String,
    val callType: String,
    val status: String,
    val time: String
)

data class ChatThread(
    val id: String = "",
    val title: String = "",
    val peerId: String = "",
    val isGroup: Boolean = false,
    val lastMessage: String = "",
    val lastTime: Long = 0L
)

data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val msgType: String = "text", // text, photo, audio
    val text: String = "",
    val mediaBase64: String = "",
    val replyAuthor: String = "",
    val replyPreview: String = "",
    val reaction: String = "",
    val deleted: Boolean = false,
    val status: String = "sent", // sent, delivered, read
    val timestamp: Long = 0L
)

data class ActiveCallSession(
    val sessionId: String,
    val remoteId: String,
    val remoteName: String,
    val callType: String,
    val isCaller: Boolean
)

data class PulsePalette(
    val name: String,
    val brand1: Color,
    val brand2: Color,
    val bg: Color,
    val card: Color,
    val bubbleOut: Color,
    val bubbleOutText: Color,
    val bubbleIn: Color,
    val bubbleInText: Color,
    val textMain: Color,
    val textMuted: Color
)

fun getPulsePalette(themeKey: String): PulsePalette = when (themeKey) {
    "light" -> PulsePalette(
        "Light", Color(0xFF00A884), Color(0xFF008069),
        Color(0xFFF0F2F5), Color.White,
        Color(0xFFD9FDD3), Color(0xFF111B21),
        Color.White, Color(0xFF111B21),
        Color(0xFF111B21), Color(0xFF667781)
    )
    "ocean" -> PulsePalette(
        "Ocean", Color(0xFF2563EB), Color(0xFF0EA5E9),
        Color(0xFF091326), Color(0xFF0F1E38),
        Color(0xFF1D4ED8), Color.White,
        Color(0xFF1E293B), Color(0xFFF1F5F9),
        Color(0xFFF8FAFC), Color(0xFF94A3B8)
    )
    "violet" -> PulsePalette(
        "Violet", Color(0xFF7C3AED), Color(0xFFEC4899),
        Color(0xFF120B1E), Color(0xFF1E1433),
        Color(0xFF7C3AED), Color.White,
        Color(0xFF2A1D45), Color(0xFFF5F3FF),
        Color(0xFFF5F3FF), Color(0xFFA78BFA)
    )
    else -> PulsePalette(
        "Dark", Color(0xFF00A884), Color(0xFF008069),
        Color(0xFF0B141A), Color(0xFF111B21),
        Color(0xFF005C4B), Color(0xFFE9EDEF),
        Color(0xFF202C33), Color(0xFFE9EDEF),
        Color(0xFFE9EDEF), Color(0xFF8696A0)
    )
}

// ==================== MAIN ACTIVITY (ZERO-FLASH SESSION) ====================
class MainActivity : ComponentActivity() {

    private val acceptedCallState = mutableStateOf<ActiveCallSession?>(null)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestAppPermissions()
        handleIncomingIntent(intent)

        // Read login session SYNCHRONOUSLY before first Compose frame -> ZERO login flash!
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val initialPeerId = prefs.getString("peer_id", "") ?: ""
        val initialName = prefs.getString("user_name", "") ?: ""
        val initialEmail = prefs.getString("user_email", "") ?: ""
        val initialTheme = prefs.getString("theme_key", "dark") ?: "dark"

        setContent {
            PulseChatNativeApp(
                initialPeerId = initialPeerId,
                initialName = initialName,
                initialEmail = initialEmail,
                initialTheme = initialTheme,
                acceptedCall = acceptedCallState.value,
                onClearAcceptedCall = { acceptedCallState.value = null }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val callerId = intent?.getStringExtra("accepted_caller_id") ?: return
        val callerName = intent.getStringExtra("accepted_caller_name") ?: callerId
        val callType = intent.getStringExtra("accepted_call_type") ?: "audio"
        val sessionId = intent.getStringExtra("accepted_session_id") ?: return

        acceptedCallState.value = ActiveCallSession(
            sessionId = sessionId,
            remoteId = callerId,
            remoteName = callerName,
            callType = callType,
            isCaller = false
        )
    }

    private fun requestAppPermissions() {
        val perms = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }
}

// ==================== HELPER UTILITIES ====================
fun computeFixedPulseId(email: String): String {
    val clean = email.trim().lowercase()
    val rawPrefix = clean.substringBefore("@").filter { it.isLetterOrDigit() }.take(3)
    val prefix = rawPrefix.ifEmpty { "usr" }.padEnd(3, 'x')
    var hash = 2166136261L
    for (ch in clean) {
        hash = hash xor ch.code.toLong()
        hash = (hash * 16777619L) and 0xFFFFFFFFL
    }
    return "pc-$prefix${1000 + (abs(hash) % 9000)}"
}

fun hashPassword(str: String): String {
    var h = 5381L
    for (c in str) h = ((h shl 5) + h) + c.code
    return "p_${abs(h).toString(36)}"
}

fun directRoomKey(a: String, b: String): String =
    if (a < b) "dm_${a}_${b}" else "dm_${b}_${a}"

fun formatTimeShort(ts: Long): String {
    if (ts <= 0L) return ""
    return SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(ts))
}

fun sendPushViaWorker(targetToken: String, title: String, body: String, dataMap: Map<String, String>) {
    if (targetToken.isBlank()) return
    CoroutineScope(Dispatchers.IO).launch {
        try {
            val url = URL(PUSH_WORKER_URL)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }
            val dataJson = JSONObject()
            dataMap.forEach { (k, v) -> dataJson.put(k, v) }
            val payload = JSONObject().apply {
                put("token", targetToken)
                put("title", title)
                put("body", body)
                put("data", dataJson)
            }
            OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }
            conn.responseCode
            conn.disconnect()
        } catch (_: Exception) {}
    }
}

fun compressImageUriToBase64(context: Context, uri: Uri): String? {
    return try {
        val input = context.contentResolver.openInputStream(uri) ?: return null
        val original = BitmapFactory.decodeStream(input)
        input.close()
        if (original == null) return null
        val maxSide = 540
        val ratio = minOf(1f, maxSide.toFloat() / maxOf(original.width, original.height))
        val scaled = if (ratio < 1f) {
            Bitmap.createScaledBitmap(
                original,
                (original.width * ratio).toInt().coerceAtLeast(1),
                (original.height * ratio).toInt().coerceAtLeast(1),
                true
            )
        } else original
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 65, out)
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    } catch (_: Exception) {
        null
    }
}

// Local JSON Persistence Helpers
fun loadSavedProfiles(context: Context): List<SavedProfile> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString("saved_profiles", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SavedProfile(o.getString("name"), o.getString("email"), o.getString("peerId"), o.getString("passwordHash"))
        }
    } catch (_: Exception) { emptyList() }
}

fun saveProfilesList(context: Context, list: List<SavedProfile>) {
    val arr = JSONArray()
    list.forEach {
        arr.put(JSONObject().apply {
            put("name", it.name)
            put("email", it.email)
            put("peerId", it.peerId)
            put("passwordHash", it.passwordHash)
        })
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString("saved_profiles", arr.toString()).apply()
}

fun loadContacts(context: Context, uid: String): List<ContactItem> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString("contacts_$uid", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ContactItem(o.getString("name"), o.getString("peerId"))
        }
    } catch (_: Exception) { emptyList() }
}

fun saveContacts(context: Context, uid: String, list: List<ContactItem>) {
    val arr = JSONArray()
    list.forEach {
        arr.put(JSONObject().apply {
            put("name", it.name)
            put("peerId", it.peerId)
        })
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString("contacts_$uid", arr.toString()).apply()
}

fun loadCallLogs(context: Context, uid: String): List<CallLogItem> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString("call_logs_$uid", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            CallLogItem(
                o.getString("id"), o.getString("name"), o.getString("peerId"),
                o.getString("callType"), o.getString("status"), o.getString("time")
            )
        }
    } catch (_: Exception) { emptyList() }
}

fun saveCallLogs(context: Context, uid: String, list: List<CallLogItem>) {
    val arr = JSONArray()
    list.take(40).forEach {
        arr.put(JSONObject().apply {
            put("id", it.id)
            put("name", it.name)
            put("peerId", it.peerId)
            put("callType", it.callType)
            put("status", it.status)
            put("time", it.time)
        })
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString("call_logs_$uid", arr.toString()).apply()
}

// ==================== ROOT APP COMPOSABLE ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PulseChatNativeApp(
    initialPeerId: String,
    initialName: String,
    initialEmail: String,
    initialTheme: String,
    acceptedCall: ActiveCallSession?,
    onClearAcceptedCall: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }

    var themeKey by remember { mutableStateOf(initialTheme) }
    val palette = getPulsePalette(themeKey)

    var myPeerId by remember { mutableStateOf(initialPeerId) }
    var userName by remember { mutableStateOf(initialName) }
    var userEmail by remember { mutableStateOf(initialEmail) }

    var savedProfiles by remember { mutableStateOf(loadSavedProfiles(context)) }
    var contacts by remember(myPeerId) { mutableStateOf(if (myPeerId.isNotBlank()) loadContacts(context, myPeerId) else emptyList()) }
    var callLogs by remember(myPeerId) { mutableStateOf(if (myPeerId.isNotBlank()) loadCallLogs(context, myPeerId) else emptyList()) }

    var allowCalls by remember { mutableStateOf(prefs.getBoolean("priv_allow_calls", true)) }
    var readReceipts by remember { mutableStateOf(prefs.getBoolean("priv_read_receipts", true)) }

    var selectedTab by remember { mutableIntStateOf(0) } // 0=Chats, 1=Contacts, 2=Calls, 3=Settings
    var chatSubTab by remember { mutableIntStateOf(0) } // 0=Direct, 1=Groups
    var activeChat by remember { mutableStateOf<ChatThread?>(null) }
    var activeCall by remember { mutableStateOf<ActiveCallSession?>(null) }
    var deleteTargetThread by remember { mutableStateOf<ChatThread?>(null) }

    fun addLog(name: String, peerId: String, callType: String, status: String) {
        val item = CallLogItem("cl_${System.currentTimeMillis()}", name, peerId, callType, status, formatTimeShort(System.currentTimeMillis()))
        callLogs = listOf(item) + callLogs
        saveCallLogs(context, myPeerId, callLogs)
    }

    fun startOutgoingCall(targetId: String, targetName: String, callType: String) {
        val cleanId = targetId.trim().lowercase()
        if (cleanId.isBlank() || cleanId == myPeerId) {
            Toast.makeText(context, "Enter a valid ID", Toast.LENGTH_SHORT).show()
            return
        }
        val sessionId = "call_${System.currentTimeMillis()}"
        activeCall = ActiveCallSession(sessionId, cleanId, targetName, callType, isCaller = true)
        addLog(targetName, cleanId, callType, "Outgoing")

        // Send high-priority data-only FCM Push to wake up receiver even if app is killed!
        FirebaseDatabase.getInstance().reference
            .child("users")
            .child(cleanId)
            .child("fcmToken")
            .get()
            .addOnSuccessListener { snap ->
                val token = snap.getValue(String::class.java) ?: ""
                sendPushViaWorker(
                    targetToken = token,
                    title = "Incoming ${if (callType == "video") "Video" else "Voice"} Call",
                    body = "$userName is calling...",
                    dataMap = mapOf(
                        "type" to "call",
                        "callerId" to myPeerId,
                        "callerName" to userName,
                        "callType" to callType,
                        "callSessionId" to sessionId
                    )
                )
            }
    }

    LaunchedEffect(acceptedCall) {
        if (acceptedCall != null) {
            activeCall = acceptedCall
            addLog(acceptedCall.remoteName, acceptedCall.remoteId, acceptedCall.callType, "Incoming")
            onClearAcceptedCall()
        }
    }

    MaterialTheme(
        colorScheme = if (themeKey == "light") {
            lightColorScheme(primary = palette.brand1, background = palette.bg, surface = palette.card)
        } else {
            darkColorScheme(
                primary = palette.brand1, background = palette.bg, surface = palette.card,
                onPrimary = Color.White, onBackground = palette.textMain, onSurface = palette.textMain
            )
        }
    ) {
        // 1. LOGIN SCREEN (Only renders if genuinely logged out—NEVER flashes on reopen!)
        if (myPeerId.isBlank()) {
            LoginScreen(
                palette = palette,
                savedProfiles = savedProfiles,
                onAuthSuccess = { name, email, passHash ->
                    val id = computeFixedPulseId(email)
                    prefs.edit()
                        .putString("user_name", name)
                        .putString("user_email", email)
                        .putString("peer_id", id)
                        .apply()
                    val updated = listOf(SavedProfile(name, email, id, passHash)) +
                        savedProfiles.filter { it.email != email }
                    savedProfiles = updated
                    saveProfilesList(context, updated)
                    userName = name
                    userEmail = email
                    myPeerId = id
                }
            )
            return@MaterialTheme
        }

        // Sync FCM token & Online presence
        LaunchedEffect(myPeerId) {
            val userRef = FirebaseDatabase.getInstance().reference.child("users").child(myPeerId)
            userRef.child("online").onDisconnect().setValue(false)
            userRef.child("lastSeen").onDisconnect().setValue(ServerValue.TIMESTAMP)
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                prefs.edit().putString("fcm_token", token).apply()
                userRef.updateChildren(
                    mapOf(
                        "peerId" to myPeerId,
                        "name" to userName,
                        "fcmToken" to token,
                        "online" to true,
                        "lastSeen" to System.currentTimeMillis()
                    )
                )
            }
        }

        // 2. ACTIVE WEBRTC CALL OVERLAY
        if (activeCall != null) {
            ActiveWebRtcCallScreen(
                call = activeCall!!,
                palette = palette,
                onEnd = { activeCall = null }
            )
            return@MaterialTheme
        }

        // 3. CHAT CONVERSATION SCREEN
        if (activeChat != null) {
            ChatConversationScreen(
                myPeerId = myPeerId,
                myName = userName,
                thread = activeChat!!,
                palette = palette,
                readReceiptsEnabled = readReceipts,
                onBack = { activeChat = null },
                onAskDelete = { deleteTargetThread = activeChat },
                onStartCall = { type -> startOutgoingCall(activeChat!!.peerId, activeChat!!.title, type) }
            )
        } else {
            // 4. MAIN 4-TAB DASHBOARD
            var threads by remember { mutableStateOf<List<ChatThread>>(emptyList()) }
            var showNewChatDialog by remember { mutableStateOf(false) }
            var showContactDialog by remember { mutableStateOf(false) }
            var editingContact by remember { mutableStateOf<ContactItem?>(null) }
            var contactSearch by remember { mutableStateOf("") }
            var quickDialId by remember { mutableStateOf("") }

            DisposableEffect(myPeerId) {
                val ref = FirebaseDatabase.getInstance().reference.child("user_chats").child(myPeerId)
                val listener = object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = mutableListOf<ChatThread>()
                        for (child in snapshot.children) {
                            child.getValue(ChatThread::class.java)?.let { list.add(it) }
                        }
                        threads = list.sortedByDescending { it.lastTime }
                    }
                    override fun onCancelled(error: DatabaseError) {}
                }
                ref.addValueEventListener(listener)
                onDispose { ref.removeEventListener(listener) }
            }

            Scaffold(
                containerColor = palette.bg,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("PulseChat", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Color.White)
                                Text("Online • ${myPeerId.uppercase()}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.85f))
                            }
                        },
                        actions = {
                            IconButton(onClick = {
                                val themes = listOf("dark", "light", "ocean", "violet")
                                val next = themes[(themes.indexOf(themeKey) + 1) % themes.size]
                                themeKey = next
                                prefs.edit().putString("theme_key", next).apply()
                            }) {
                                Icon(Icons.Default.Palette, contentDescription = "Theme", tint = Color.White)
                            }
                            IconButton(onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("PulseChat ID", myPeerId))
                                Toast.makeText(context, "Copied: $myPeerId", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy ID", tint = Color.White)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = palette.brand2)
                    )
                },
                floatingActionButton = {
                    if (selectedTab == 0 || selectedTab == 1) {
                        FloatingActionButton(
                            onClick = {
                                if (selectedTab == 0) showNewChatDialog = true
                                else {
                                    editingContact = null
                                    showContactDialog = true
                                }
                            },
                            containerColor = palette.brand1,
                            contentColor = Color.White,
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(
                                if (selectedTab == 1) Icons.Default.PersonAdd
                                else if (chatSubTab == 1) Icons.Default.GroupAdd
                                else Icons.Default.Chat,
                                contentDescription = "Action"
                            )
                        }
                    }
                },
                bottomBar = {
                    NavigationBar(containerColor = palette.card) {
                        val navItems = listOf(
                            Triple("Chats", Icons.Default.Chat, 0),
                            Triple("Contacts", Icons.Default.Contacts, 1),
                            Triple("Calls", Icons.Default.Call, 2),
                            Triple("Settings", Icons.Default.Settings, 3)
                        )
                        navItems.forEach { (label, icon, idx) ->
                            NavigationBarItem(
                                selected = selectedTab == idx,
                                onClick = { selectedTab = idx },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = palette.brand1,
                                    indicatorColor = palette.brand1
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                Box(modifier = Modifier.fillMaxSize().padding(padding)) {
                    when (selectedTab) {
                        // TAB 0: CHATS & GROUPS
                        0 -> {
                            Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                                // Direct / Groups Sub-tabs
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(palette.card)
                                        .padding(4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val directCount = threads.count { !it.isGroup }
                                    val groupCount = threads.count { it.isGroup }
                                    listOf("Chats ($directCount)" to 0, "Groups ($groupCount)" to 1).forEach { (title, idx) ->
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(if (chatSubTab == idx) palette.brand1 else Color.Transparent)
                                                .clickable { chatSubTab = idx }
                                                .padding(vertical = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                title,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (chatSubTab == idx) Color.White else palette.textMuted
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                val list = threads.filter { if (chatSubTab == 1) it.isGroup else !it.isGroup }

                                if (list.isEmpty()) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text(
                                            if (chatSubTab == 1) "No groups yet. Tap + to create or join." else "No chats yet. Tap + to start chatting.",
                                            color = palette.textMuted,
                                            fontSize = 13.sp
                                        )
                                    }
                                } else {
                                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        items(list, key = { it.id }) { thread ->
                                            val displayName = contacts.find { it.peerId == thread.peerId }?.name ?: thread.title
                                            Card(
                                                colors = CardDefaults.cardColors(containerColor = palette.card),
                                                shape = RoundedCornerShape(18.dp),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { activeChat = thread.copy(title = displayName) }
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(14.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(48.dp)
                                                            .clip(CircleShape)
                                                            .background(if (thread.isGroup) Color(0xFFD97706) else palette.brand1),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        if (thread.isGroup) {
                                                            Icon(Icons.Default.Groups, contentDescription = null, tint = Color.White)
                                                        } else {
                                                            Text(
                                                                displayName.firstOrNull()?.uppercase() ?: "U",
                                                                color = Color.White,
                                                                fontWeight = FontWeight.ExtraBold,
                                                                fontSize = 18.sp
                                                            )
                                                        }
                                                    }
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween
                                                        ) {
                                                            Text(
                                                                displayName,
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 15.sp,
                                                                color = palette.textMain,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis,
                                                                modifier = Modifier.weight(1f)
                                                            )
                                                            Text(
                                                                formatTimeShort(thread.lastTime),
                                                                fontSize = 10.sp,
                                                                color = palette.textMuted
                                                            )
                                                        }
                                                        Spacer(modifier = Modifier.height(2.dp))
                                                        Text(
                                                            thread.lastMessage.ifBlank { thread.peerId },
                                                            fontSize = 12.sp,
                                                            color = palette.textMuted,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    }
                                                    IconButton(onClick = { deleteTargetThread = thread }) {
                                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFF43F5E))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // TAB 1: CONTACTS
                        1 -> {
                            Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                                OutlinedTextField(
                                    value = contactSearch,
                                    onValueChange = { contactSearch = it },
                                    placeholder = { Text("Search contacts...") },
                                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                val filtered = contacts.filter {
                                    it.name.contains(contactSearch, ignoreCase = true) ||
                                        it.peerId.contains(contactSearch, ignoreCase = true)
                                }
                                if (filtered.isEmpty()) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text("No contacts saved. Tap + to add.", color = palette.textMuted, fontSize = 13.sp)
                                    }
                                } else {
                                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        items(filtered, key = { it.peerId }) { c ->
                                            Card(
                                                colors = CardDefaults.cardColors(containerColor = palette.card),
                                                shape = RoundedCornerShape(18.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .clickable {
                                                            val tid = directRoomKey(myPeerId, c.peerId)
                                                            val thread = ChatThread(tid, c.name, c.peerId, false, "", System.currentTimeMillis())
                                                            FirebaseDatabase.getInstance().reference
                                                                .child("user_chats").child(myPeerId).child(tid).setValue(thread)
                                                            activeChat = thread
                                                        }
                                                        .padding(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Box(
                                                        modifier = Modifier.size(44.dp).clip(CircleShape).background(palette.brand1),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(c.name.firstOrNull()?.uppercase() ?: "C", color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(c.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = palette.textMain)
                                                        Text(c.peerId, fontSize = 11.sp, color = palette.textMuted)
                                                    }
                                                    IconButton(onClick = { startOutgoingCall(c.peerId, c.name, "audio") }) {
                                                        Icon(Icons.Default.Call, contentDescription = "Audio", tint = palette.brand1)
                                                    }
                                                    IconButton(onClick = { startOutgoingCall(c.peerId, c.name, "video") }) {
                                                        Icon(Icons.Default.Videocam, contentDescription = "Video", tint = Color(0xFF38BDF8))
                                                    }
                                                    IconButton(onClick = {
                                                        editingContact = c
                                                        showContactDialog = true
                                                    }) {
                                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = palette.textMuted)
                                                    }
                                                    IconButton(onClick = {
                                                        contacts = contacts.filter { it.peerId != c.peerId }
                                                        saveContacts(context, myPeerId, contacts)
                                                    }) {
                                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFF43F5E))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // TAB 2: CALLS
                        2 -> {
                            Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = palette.card),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        OutlinedTextField(
                                            value = quickDialId,
                                            onValueChange = { quickDialId = it },
                                            placeholder = { Text("Enter ID (e.g. pc-sam4821)") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            Button(
                                                onClick = {
                                                    val cid = quickDialId.trim().lowercase()
                                                    val cname = contacts.find { it.peerId == cid }?.name ?: cid.uppercase()
                                                    startOutgoingCall(cid, cname, "audio")
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = palette.brand2),
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(14.dp)
                                            ) {
                                                Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Audio Call", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Button(
                                                onClick = {
                                                    val cid = quickDialId.trim().lowercase()
                                                    val cname = contacts.find { it.peerId == cid }?.name ?: cid.uppercase()
                                                    startOutgoingCall(cid, cname, "video")
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = palette.brand1),
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(14.dp)
                                            ) {
                                                Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Video Call", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("RECENT CALLS", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = palette.textMuted)
                                    if (callLogs.isNotEmpty()) {
                                        Text(
                                            "Clear All",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFF43F5E),
                                            modifier = Modifier.clickable {
                                                callLogs = emptyList()
                                                saveCallLogs(context, myPeerId, emptyList())
                                            }
                                        )
                                    }
                                }

                                if (callLogs.isEmpty()) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text("No recent calls", color = palette.textMuted, fontSize = 13.sp)
                                    }
                                } else {
                                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        items(callLogs, key = { it.id }) { log ->
                                            Card(
                                                colors = CardDefaults.cardColors(containerColor = palette.card),
                                                shape = RoundedCornerShape(16.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Box(
                                                        modifier = Modifier.size(40.dp).clip(CircleShape).background(palette.brand1.copy(alpha = 0.2f)),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            if (log.callType == "video") Icons.Default.Videocam else Icons.Default.Call,
                                                            contentDescription = null,
                                                            tint = palette.brand1
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(log.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = palette.textMain)
                                                        Text("${log.status} • ${log.time}", fontSize = 11.sp, color = palette.textMuted)
                                                    }
                                                    IconButton(onClick = { startOutgoingCall(log.peerId, log.name, log.callType) }) {
                                                        Icon(Icons.Default.Call, contentDescription = "Redial", tint = palette.brand1)
                                                    }
                                                    IconButton(onClick = {
                                                        callLogs = callLogs.filter { it.id != log.id }
                                                        saveCallLogs(context, myPeerId, callLogs)
                                                    }) {
                                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFF43F5E))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // TAB 3: SETTINGS
                        3 -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Card(colors = CardDefaults.cardColors(containerColor = palette.card), shape = RoundedCornerShape(20.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier.size(56.dp).clip(CircleShape).background(palette.brand1),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(userName.firstOrNull()?.uppercase() ?: "U", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                                        }
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column {
                                            Text(userName, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = palette.textMain)
                                            Text(userEmail, fontSize = 12.sp, color = palette.textMuted)
                                            Text("ID: $myPeerId", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = palette.brand1)
                                        }
                                    }
                                }

                                // 4 Theme Selector
                                Card(colors = CardDefaults.cardColors(containerColor = palette.card), shape = RoundedCornerShape(20.dp)) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("APPEARANCE", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = palette.textMuted)
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            listOf(
                                                Triple("dark", "Dark", Color(0xFF111B21)),
                                                Triple("light", "Light", Color(0xFFFFFFFF)),
                                                Triple("ocean", "Ocean", Color(0xFF2563EB)),
                                                Triple("violet", "Violet", Color(0xFF7C3AED))
                                            ).forEach { (key, label, swatch) ->
                                                Column(
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .clip(RoundedCornerShape(14.dp))
                                                        .border(
                                                            width = if (themeKey == key) 2.dp else 1.dp,
                                                            color = if (themeKey == key) palette.brand1 else palette.textMuted.copy(alpha = 0.2f),
                                                            shape = RoundedCornerShape(14.dp)
                                                        )
                                                        .clickable {
                                                            themeKey = key
                                                            prefs.edit().putString("theme_key", key).apply()
                                                        }
                                                        .padding(vertical = 10.dp)
                                                ) {
                                                    Box(modifier = Modifier.size(26.dp).clip(CircleShape).background(swatch).border(1.dp, palette.brand1, CircleShape))
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = palette.textMain)
                                                }
                                            }
                                        }
                                    }
                                }

                                // Privacy Controls
                                Card(colors = CardDefaults.cardColors(containerColor = palette.card), shape = RoundedCornerShape(20.dp)) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Allow Incoming Calls", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = palette.textMain)
                                            Switch(checked = allowCalls, onCheckedChange = {
                                                allowCalls = it
                                                prefs.edit().putBoolean("priv_allow_calls", it).apply()
                                            })
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Read Receipts (Blue Ticks)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = palette.textMain)
                                            Switch(checked = readReceipts, onCheckedChange = {
                                                readReceipts = it
                                                prefs.edit().putBoolean("priv_read_receipts", it).apply()
                                            })
                                        }
                                    }
                                }

                                Button(
                                    onClick = {
                                        prefs.edit().remove("peer_id").remove("user_name").remove("user_email").apply()
                                        myPeerId = ""
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.fillMaxWidth().height(50.dp)
                                ) {
                                    Text("Logout", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }

            // Dialog: New Chat or Group
            if (showNewChatDialog) {
                var inputName by remember { mutableStateOf("") }
                var inputId by remember { mutableStateOf("") }
                val isGroup = chatSubTab == 1
                AlertDialog(
                    onDismissRequest = { showNewChatDialog = false },
                    title = { Text(if (isGroup) "Create / Join Group" else "Start New Chat") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = inputName,
                                onValueChange = { inputName = it },
                                label = { Text(if (isGroup) "Group Name" else "Name (optional)") },
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = inputId,
                                onValueChange = { inputId = it },
                                label = { Text(if (isGroup) "Group ID (e.g. grp-101)" else "User ID (e.g. pc-sam4821)") },
                                singleLine = true
                            )
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            val cleanId = inputId.trim().lowercase()
                            if (cleanId.isNotBlank()) {
                                val threadId = if (isGroup) "grp_$cleanId" else directRoomKey(myPeerId, cleanId)
                                val title = inputName.trim().ifEmpty { contacts.find { it.peerId == cleanId }?.name ?: cleanId.uppercase() }
                                val thread = ChatThread(threadId, title, cleanId, isGroup, "", System.currentTimeMillis())
                                FirebaseDatabase.getInstance().reference
                                    .child("user_chats").child(myPeerId).child(threadId).setValue(thread)
                                showNewChatDialog = false
                                activeChat = thread
                            }
                        }) { Text("Open") }
                    },
                    dismissButton = { TextButton(onClick = { showNewChatDialog = false }) { Text("Cancel") } }
                )
            }

            // Dialog: Add / Edit Contact
            if (showContactDialog) {
                var cName by remember { mutableStateOf(editingContact?.name ?: "") }
                var cId by remember { mutableStateOf(editingContact?.peerId ?: "") }
                AlertDialog(
                    onDismissRequest = { showContactDialog = false },
                    title = { Text(if (editingContact == null) "Add Contact" else "Edit Contact") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = cName, onValueChange = { cName = it }, label = { Text("Name") }, singleLine = true)
                            OutlinedTextField(value = cId, onValueChange = { cId = it }, label = { Text("PulseChat ID") }, singleLine = true)
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            val cleanId = cId.trim().lowercase()
                            if (cName.isNotBlank() && cleanId.isNotBlank() && cleanId != myPeerId) {
                                val oldId = editingContact?.peerId
                                val updated = listOf(ContactItem(cName.trim(), cleanId)) +
                                    contacts.filter { it.peerId != cleanId && it.peerId != oldId }
                                contacts = updated
                                saveContacts(context, myPeerId, updated)
                                showContactDialog = false
                            }
                        }) { Text("Save") }
                    },
                    dismissButton = { TextButton(onClick = { showContactDialog = false }) { Text("Cancel") } }
                )
            }
        }

        // Shared Dialog: Delete / Clear Chat or Group
        if (deleteTargetThread != null) {
            val target = deleteTargetThread!!
            AlertDialog(
                onDismissRequest = { deleteTargetThread = null },
                title = { Text(if (target.isGroup) "Group: ${target.title}" else "Chat: ${target.title}") },
                text = { Text("Clear messages only or delete completely?") },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = {
                            FirebaseDatabase.getInstance().reference.child("messages").child(target.id).removeValue()
                            deleteTargetThread = null
                            Toast.makeText(context, "Messages cleared", Toast.LENGTH_SHORT).show()
                        }) { Text("Clear Only", color = Color(0xFFF59E0B)) }
                        Button(
                            onClick = {
                                FirebaseDatabase.getInstance().reference
                                    .child("user_chats").child(myPeerId).child(target.id).removeValue()
                                if (activeChat?.id == target.id) activeChat = null
                                deleteTargetThread = null
                                Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48))
                        ) { Text("Delete") }
                    }
                },
                dismissButton = { TextButton(onClick = { deleteTargetThread = null }) { Text("Cancel") } }
            )
        }
    }
}

// ==================== LOGIN SCREEN ====================
@Composable
fun LoginScreen(
    palette: PulsePalette,
    savedProfiles: List<SavedProfile>,
    onAuthSuccess: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.bg)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(84.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(palette.brand1, palette.brand2))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(42.dp))
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text("PulseChat", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = palette.textMain)
        Text("Pure Native Android Messenger", fontSize = 12.sp, color = palette.brand1)
        Spacer(modifier = Modifier.height(26.dp))

        if (errorMsg.isNotBlank()) {
            Text(errorMsg, color = Color(0xFFF43F5E), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
        }

        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Your Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (email.contains("@")) {
            Text("ID: ${computeFixedPulseId(email)}", color = palette.brand1, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start).padding(top = 4.dp))
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (min 4 chars)") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = {
                val cleanEmail = email.trim().lowercase()
                if (name.isBlank() || !cleanEmail.contains("@") || password.length < 4) {
                    errorMsg = "Enter valid name, email & 4+ char password"
                    return@Button
                }
                val hash = hashPassword(password)
                val existing = savedProfiles.find { it.email == cleanEmail }
                if (existing != null && existing.passwordHash != hash) {
                    errorMsg = "Incorrect password for this account"
                    return@Button
                }
                onAuthSuccess(name.trim(), cleanEmail, hash)
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = palette.brand1)
        ) {
            Text("Continue", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
        }

        if (savedProfiles.isNotEmpty()) {
            Spacer(modifier = Modifier.height(24.dp))
            Text("SAVED ACCOUNTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = palette.textMuted)
            Spacer(modifier = Modifier.height(8.dp))
            savedProfiles.forEach { p ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = palette.card),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onAuthSuccess(p.name, p.email, p.passwordHash) }
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(p.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = palette.textMain)
                            Text(p.email, fontSize = 11.sp, color = palette.textMuted)
                        }
                        Text(p.peerId, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = palette.brand1)
                    }
                }
            }
        }
    }
}

// ==================== CHAT CONVERSATION SCREEN (PHOTO, VOICE, REPLY, REACT, DELETE) ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatConversationScreen(
    myPeerId: String,
    myName: String,
    thread: ChatThread,
    palette: PulsePalette,
    readReceiptsEnabled: Boolean,
    onBack: () -> Unit,
    onAskDelete: () -> Unit,
    onStartCall: (String) -> Unit
) {
    val context = LocalContext.current
    val listState = rememberLazyListState()

    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var draftText by remember { mutableStateOf("") }
    var isRemoteOnline by remember { mutableStateOf(false) }
    var isRemoteTyping by remember { mutableStateOf(false) }

    var replyTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var actionMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var lightboxBitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Voice Note Recording State
    var isRecording by remember { mutableStateOf(false) }
    var recSeconds by remember { mutableIntStateOf(0) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var voiceFile by remember { mutableStateOf<File?>(null) }

    fun sendFirebaseMessage(msgType: String, text: String, mediaBase64: String = "") {
        val msgId = "m_${System.currentTimeMillis()}_${(100..999).random()}"
        val now = System.currentTimeMillis()
        val msg = ChatMessage(
            id = msgId,
            senderId = myPeerId,
            senderName = myName,
            msgType = msgType,
            text = text,
            mediaBase64 = mediaBase64,
            replyAuthor = replyTarget?.let { if (it.senderId == myPeerId) "You" else it.senderName } ?: "",
            replyPreview = replyTarget?.let {
                when (it.msgType) {
                    "photo" -> "Photo"
                    "audio" -> "Voice Note"
                    else -> it.text.take(60)
                }
            } ?: "",
            status = "sent",
            timestamp = now
        )
        replyTarget = null
        val preview = when (msgType) {
            "photo" -> "Photo"
            "audio" -> "Voice message"
            else -> text
        }

        val db = FirebaseDatabase.getInstance().reference
        db.child("messages").child(thread.id).child(msgId).setValue(msg)
        db.child("user_chats").child(myPeerId).child(thread.id).updateChildren(
            mapOf("lastMessage" to preview, "lastTime" to now)
        )

        if (!thread.isGroup) {
            db.child("typing").child(thread.id).child(myPeerId).setValue(false)
            val receiverThread = ChatThread(thread.id, myName, myPeerId, false, preview, now)
            db.child("user_chats").child(thread.peerId).child(thread.id).setValue(receiverThread)

            db.child("users").child(thread.peerId).child("fcmToken").get().addOnSuccessListener { snap ->
                val token = snap.getValue(String::class.java) ?: ""
                sendPushViaWorker(token, myName, preview, mapOf("type" to "message", "title" to myName, "body" to preview))
            }
        }
    }

    // Gallery Photo Picker
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val b64 = compressImageUriToBase64(context, uri)
            if (b64 != null) sendFirebaseMessage("photo", "Photo", b64)
            else Toast.makeText(context, "Could not load photo", Toast.LENGTH_SHORT).show()
        }
    }

    // Recording Timer
    LaunchedEffect(isRecording) {
        if (isRecording) {
            recSeconds = 0
            while (isRecording) {
                delay(1000)
                recSeconds++
            }
        }
    }

    // Listen Messages + Mark Read Receipts
    DisposableEffect(thread.id) {
        val db = FirebaseDatabase.getInstance().reference
        val msgRef = db.child("messages").child(thread.id)
        val msgListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<ChatMessage>()
                for (child in snapshot.children) {
                    val m = child.getValue(ChatMessage::class.java) ?: continue
                    list.add(m)
                    if (m.senderId != myPeerId && m.status != "read") {
                        msgRef.child(m.id).child("status").setValue(if (readReceiptsEnabled) "read" else "delivered")
                    }
                }
                messages = list.sortedBy { it.timestamp }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        msgRef.addValueEventListener(msgListener)

        // Listen Online & Typing for Direct Chats
        var onlineListener: ValueEventListener? = null
        var typingListener: ValueEventListener? = null
        if (!thread.isGroup) {
            onlineListener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    isRemoteOnline = s.getValue(Boolean::class.java) == true
                }
                override fun onCancelled(e: DatabaseError) {}
            }
            db.child("users").child(thread.peerId).child("online").addValueEventListener(onlineListener)

            typingListener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    isRemoteTyping = s.getValue(Boolean::class.java) == true
                }
                override fun onCancelled(e: DatabaseError) {}
            }
            db.child("typing").child(thread.id).child(thread.peerId).addValueEventListener(typingListener)
        }

        onDispose {
            msgRef.removeEventListener(msgListener)
            onlineListener?.let { db.child("users").child(thread.peerId).child("online").removeEventListener(it) }
            typingListener?.let { db.child("typing").child(thread.id).child(thread.peerId).removeEventListener(it) }
            if (!thread.isGroup) db.child("typing").child(thread.id).child(myPeerId).setValue(false)
            try { recorder?.release() } catch (_: Exception) {}
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        containerColor = palette.bg,
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                title = {
                    Column {
                        Text(thread.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            text = when {
                                thread.isGroup -> "Group • ${thread.peerId}"
                                isRemoteTyping -> "typing..."
                                isRemoteOnline -> "online"
                                else -> thread.peerId
                            },
                            fontSize = 11.sp,
                            color = if (isRemoteTyping || isRemoteOnline) Color(0xFF6EE7B7) else Color.White.copy(alpha = 0.8f)
                        )
                    }
                },
                actions = {
                    if (!thread.isGroup) {
                        IconButton(onClick = { onStartCall("audio") }) {
                            Icon(Icons.Default.Call, contentDescription = "Audio Call", tint = Color.White)
                        }
                        IconButton(onClick = { onStartCall("video") }) {
                            Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = Color.White)
                        }
                    }
                    IconButton(onClick = onAskDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = palette.brand2)
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val isMe = msg.senderId == myPeerId
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                    ) {
                        Box {
                            Column(
                                modifier = Modifier
                                    .widthIn(max = 280.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isMe) palette.bubbleOut else palette.bubbleIn)
                                    .clickable { if (!msg.deleted) actionMessage = msg }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                if (!isMe && thread.isGroup) {
                                    Text(msg.senderName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = palette.brand1)
                                }
                                if (msg.replyPreview.isNotBlank() && !msg.deleted) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 4.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color.Black.copy(alpha = 0.15f))
                                            .padding(6.dp)
                                    ) {
                                        Text(msg.replyAuthor, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = palette.brand1)
                                        Text(msg.replyPreview, fontSize = 11.sp, color = (if (isMe) palette.bubbleOutText else palette.bubbleInText).copy(alpha = 0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }

                                val textColor = if (isMe) palette.bubbleOutText else palette.bubbleInText
                                when {
                                    msg.deleted -> {
                                        Text("This message was deleted", fontStyle = FontStyle.Italic, fontSize = 12.sp, color = textColor.copy(alpha = 0.6f))
                                    }
                                    msg.msgType == "photo" && msg.mediaBase64.isNotBlank() -> {
                                        val bmp = remember(msg.mediaBase64) {
                                            try {
                                                val bytes = Base64.decode(msg.mediaBase64, Base64.DEFAULT)
                                                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                            } catch (_: Exception) { null }
                                        }
                                        if (bmp != null) {
                                            Image(
                                                bitmap = bmp.asImageBitmap(),
                                                contentDescription = "Photo",
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(190.dp)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .clickable { lightboxBitmap = bmp }
                                            )
                                        }
                                    }
                                    msg.msgType == "audio" && msg.mediaBase64.isNotBlank() -> {
                                        VoiceNotePlayerBubble(base64Audio = msg.mediaBase64, tintColor = textColor)
                                    }
                                    else -> {
                                        Text(msg.text, color = textColor, fontSize = 14.sp)
                                    }
                                }

                                Row(
                                    modifier = Modifier.align(Alignment.End).padding(top = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(formatTimeShort(msg.timestamp), fontSize = 9.sp, color = textColor.copy(alpha = 0.65f))
                                    if (isMe) {
                                        val tickIcon = if (msg.status == "sent") Icons.Default.Check else Icons.Default.DoneAll
                                        val tickTint = if (msg.status == "read") Color(0xFF38BDF8) else textColor.copy(alpha = 0.65f)
                                        Icon(tickIcon, contentDescription = null, tint = tickTint, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                            if (msg.reaction.isNotBlank() && !msg.deleted) {
                                Text(
                                    msg.reaction,
                                    fontSize = 14.sp,
                                    modifier = Modifier
                                        .align(if (isMe) Alignment.BottomStart else Alignment.BottomEnd)
                                        .offset(y = 10.dp)
                                        .clip(CircleShape)
                                        .background(palette.card)
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Reply Preview Bar
            if (replyTarget != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.card)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            if (replyTarget!!.senderId == myPeerId) "Replying to You" else "Replying to ${replyTarget!!.senderName}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.brand1
                        )
                        Text(replyTarget!!.text.ifBlank { replyTarget!!.msgType }, fontSize = 12.sp, color = palette.textMuted, maxLines = 1)
                    }
                    IconButton(onClick = { replyTarget = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = palette.textMuted)
                    }
                }
            }

            // Recording Banner
            if (isRecording) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFE11D48)).padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recording Voice Note... 00:${recSeconds.toString().padStart(2, '0')}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        "Cancel",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        modifier = Modifier.clickable {
                            isRecording = false
                            try { recorder?.stop(); recorder?.release() } catch (_: Exception) {}
                            recorder = null
                            voiceFile?.delete()
                        }
                    )
                }
            }

            // Bottom Composer Bar
            Row(
                modifier = Modifier.fillMaxWidth().background(palette.card).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { photoPicker.launch("image/*") }) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = "Photo", tint = palette.brand1)
                }
                OutlinedTextField(
                    value = draftText,
                    onValueChange = {
                        draftText = it
                        if (!thread.isGroup) {
                            FirebaseDatabase.getInstance().reference
                                .child("typing").child(thread.id).child(myPeerId).setValue(it.isNotBlank())
                        }
                    },
                    placeholder = { Text("Message") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(6.dp))

                // Voice Note Mic Button
                IconButton(onClick = {
                    if (!isRecording) {
                        try {
                            val file = File(context.cacheDir, "vn_${System.currentTimeMillis()}.m4a")
                            val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
                            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
                            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                            mr.setOutputFile(file.absolutePath)
                            mr.prepare()
                            mr.start()
                            recorder = mr
                            voiceFile = file
                            isRecording = true
                        } catch (_: Exception) {
                            Toast.makeText(context, "Mic permission needed", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        isRecording = false
                        try {
                            recorder?.stop()
                            recorder?.release()
                            recorder = null
                            val bytes = voiceFile?.readBytes()
                            if (bytes != null && bytes.isNotEmpty()) {
                                val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                                sendFirebaseMessage("audio", "Voice Note", b64)
                            }
                            voiceFile?.delete()
                        } catch (_: Exception) {}
                    }
                }) {
                    Icon(
                        if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Voice Note",
                        tint = if (isRecording) Color(0xFFE11D48) else palette.brand1
                    )
                }

                FloatingActionButton(
                    onClick = {
                        val txt = draftText.trim()
                        if (txt.isNotEmpty()) {
                            sendFirebaseMessage("text", txt)
                            draftText = ""
                        }
                    },
                    containerColor = palette.brand1,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(46.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                }
            }
        }
    }

    // Message Action Dialog (React / Reply / Copy / Delete for Everyone)
    if (actionMessage != null) {
        val m = actionMessage!!
        AlertDialog(
            onDismissRequest = { actionMessage = null },
            title = {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("❤️", "👍", "😂", "🔥", "🙏").forEach { emoji ->
                        Text(
                            emoji,
                            fontSize = 24.sp,
                            modifier = Modifier.clickable {
                                val newReact = if (m.reaction == emoji) "" else emoji
                                FirebaseDatabase.getInstance().reference
                                    .child("messages").child(thread.id).child(m.id).child("reaction").setValue(newReact)
                                actionMessage = null
                            }
                        )
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { replyTarget = m; actionMessage = null }, modifier = Modifier.fillMaxWidth()) {
                        Text("Reply")
                    }
                    if (m.msgType == "text") {
                        TextButton(onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("Message", m.text))
                            Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                            actionMessage = null
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text("Copy Text")
                        }
                    }
                    if (m.senderId == myPeerId) {
                        TextButton(onClick = {
                            FirebaseDatabase.getInstance().reference
                                .child("messages").child(thread.id).child(m.id)
                                .updateChildren(mapOf("deleted" to true, "text" to "This message was deleted", "mediaBase64" to ""))
                            actionMessage = null
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text("Delete for Everyone", color = Color(0xFFE11D48))
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // Full-Screen Photo Lightbox
    if (lightboxBitmap != null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.95f))
                .clickable { lightboxBitmap = null },
            contentAlignment = Alignment.Center
        ) {
            Image(
                bitmap = lightboxBitmap!!.asImageBitmap(),
                contentDescription = "Zoom",
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
fun VoiceNotePlayerBubble(base64Audio: String, tintColor: Color) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(Unit) {
        onDispose { try { player?.release() } catch (_: Exception) {} }
    }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconButton(
            onClick = {
                if (isPlaying) {
                    try { player?.stop(); player?.release() } catch (_: Exception) {}
                    player = null
                    isPlaying = false
                } else {
                    try {
                        val bytes = Base64.decode(base64Audio, Base64.DEFAULT)
                        val tmp = File(context.cacheDir, "play_${System.currentTimeMillis()}.m4a")
                        FileOutputStream(tmp).use { it.write(bytes) }
                        val mp = MediaPlayer().apply {
                            setDataSource(tmp.absolutePath)
                            prepare()
                            start()
                            setOnCompletionListener {
                                isPlaying = false
                                release()
                                tmp.delete()
                            }
                        }
                        player = mp
                        isPlaying = true
                    } catch (_: Exception) {}
                }
            },
            modifier = Modifier.size(34.dp)
        ) {
            Icon(if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow, contentDescription = "Play", tint = tintColor)
        }
        Text(if (isPlaying) "Playing voice note..." else "Voice message", color = tintColor, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

// ==================== ACTIVE NATIVE WEBRTC CALL SCREEN ====================
@Composable
fun ActiveWebRtcCallScreen(
    call: ActiveCallSession,
    palette: PulsePalette,
    onEnd: () -> Unit
) {
    val context = LocalContext.current
    var statusText by remember { mutableStateOf(if (call.isCaller) "Ringing..." else "Connecting...") }
    var callSeconds by remember { mutableIntStateOf(0) }
    var isMuted by remember { mutableStateOf(false) }
    var isCamOff by remember { mutableStateOf(false) }
    var isSpeaker by remember { mutableStateOf(call.callType == "video") }

    val engine = remember(call.sessionId) {
        WebRtcCallEngine(
            context = context,
            sessionId = call.sessionId,
            isCaller = call.isCaller,
            isVideo = call.callType == "video",
            onStatusChange = { statusText = it },
            onCallEnded = { onEnd() }
        )
    }

    DisposableEffect(call.sessionId) {
        engine.start()
        onDispose { engine.end(notifyRemote = true) }
    }

    LaunchedEffect(statusText) {
        if (statusText == "Connected") {
            while (true) {
                delay(1000)
                callSeconds++
            }
        }
    }

    val timerStr = if (statusText == "Connected") {
        "${(callSeconds / 60).toString().padStart(2, '0')}:${(callSeconds % 60).toString().padStart(2, '0')}"
    } else statusText

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0B141A))) {
        // Remote Full-Screen Video Renderer
        if (call.callType == "video") {
            AndroidView(
                factory = { ctx -> SurfaceViewRenderer(ctx).also { engine.attachRemoteRenderer(it) } },
                modifier = Modifier.fillMaxSize()
            )
            // Local PiP Video Renderer
            AndroidView(
                factory = { ctx -> SurfaceViewRenderer(ctx).also { engine.attachLocalRenderer(it) } },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = 120.dp)
                    .size(width = 110.dp, height = 160.dp)
                    .clip(RoundedCornerShape(18.dp))
            )
        } else {
            // Audio Call Center Stage
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(116.dp).clip(CircleShape).background(palette.brand1),
                    contentAlignment = Alignment.Center
                ) {
                    Text(call.remoteName.firstOrNull()?.uppercase() ?: "U", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(modifier = Modifier.height(18.dp))
                Text(call.remoteName, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(timerStr, color = Color(0xFF34D399), fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Video Top Bar
        if (call.callType == "video") {
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 42.dp, start = 20.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(call.remoteName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(timerStr, color = Color(0xFF34D399), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Bottom Controls Bar
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 20.dp, vertical = 32.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xFF111B21).copy(alpha = 0.9f))
                .padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                isMuted = !isMuted
                engine.setMicMuted(isMuted)
            }) {
                Icon(if (isMuted) Icons.Default.MicOff else Icons.Default.Mic, contentDescription = "Mute", tint = Color.White)
            }
            IconButton(onClick = {
                isSpeaker = !isSpeaker
                engine.setSpeakerOn(isSpeaker)
            }) {
                Icon(if (isSpeaker) Icons.Default.VolumeUp else Icons.Default.VolumeDown, contentDescription = "Speaker", tint = Color.White)
            }
            if (call.callType == "video") {
                IconButton(onClick = {
                    isCamOff = !isCamOff
                    engine.setCameraOff(isCamOff)
                }) {
                    Icon(if (isCamOff) Icons.Default.VideocamOff else Icons.Default.Videocam, contentDescription = "Camera", tint = Color.White)
                }
                IconButton(onClick = { engine.switchCamera() }) {
                    Icon(Icons.Default.Cameraswitch, contentDescription = "Switch Cam", tint = Color.White)
                }
            }
            FloatingActionButton(
                onClick = {
                    engine.end(notifyRemote = true)
                    onEnd()
                },
                containerColor = Color(0xFFE11D48),
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.size(56.dp)
            ) {
                Icon(Icons.Default.CallEnd, contentDescription = "Hang Up")
            }
        }
    }
}
package com.pulsechat.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class PulseFirebaseService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val prefs = getSharedPreferences("pulsechat_native_v2", Context.MODE_PRIVATE)
        prefs.edit().putString("fcm_token", token).apply()

        val peerId = prefs.getString("peer_id", null)
        if (!peerId.isNullOrBlank()) {
            try {
                FirebaseDatabase.getInstance().reference
                    .child("users")
                    .child(peerId)
                    .child("fcmToken")
                    .setValue(token)
            } catch (_: Exception) {}
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val prefs = getSharedPreferences("pulsechat_native_v2", Context.MODE_PRIVATE)
        val allowCalls = prefs.getBoolean("priv_allow_calls", true)

        val data = message.data
        val type = data["type"] ?: "message"

        if (type == "call") {
            val callerId = data["callerId"] ?: "unknown"
            val callerName = data["callerName"] ?: message.notification?.title ?: "Incoming Call"
            val callType = data["callType"] ?: "audio"
            val sessionId = data["callSessionId"] ?: System.currentTimeMillis().toString()

            if (!allowCalls) {
                try {
                    FirebaseDatabase.getInstance().reference
                        .child("calls")
                        .child(sessionId)
                        .child("status")
                        .setValue("declined")
                } catch (_: Exception) {}
                return
            }

            showIncomingCallNotification(callerId, callerName, callType, sessionId)
        } else {
            val title = data["title"] ?: message.notification?.title ?: "PulseChat"
            val body = data["body"] ?: message.notification?.body ?: "New message"
            showMessageNotification(title, body)
        }
    }

    private fun showIncomingCallNotification(
        callerId: String,
        callerName: String,
        callType: String,
        sessionId: String
    ) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "pulsechat_calls_v2"
        val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Incoming Calls",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "WhatsApp-style full-screen incoming calls"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 800, 600, 800)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setSound(
                    ringtoneUri,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
            manager.createNotificationChannel(channel)
        }

        // Full-Screen Intent (wakes lock screen & opens animated IncomingCallActivity)
        val fullScreenIntent = Intent(this, IncomingCallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("callerId", callerId)
            putExtra("callerName", callerName)
            putExtra("callType", callType)
            putExtra("callSessionId", sessionId)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            1001,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Direct Accept button in notification shade
        val acceptIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("accepted_caller_id", callerId)
            putExtra("accepted_caller_name", callerName)
            putExtra("accepted_call_type", callType)
            putExtra("accepted_session_id", sessionId)
        }
        val acceptPendingIntent = PendingIntent.getActivity(
            this,
            1002,
            acceptIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Direct Decline button in notification shade
        val declineIntent = Intent(this, IncomingCallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("action_decline", true)
            putExtra("callerId", callerId)
            putExtra("callSessionId", sessionId)
        }
        val declinePendingIntent = PendingIntent.getActivity(
            this,
            1003,
            declineIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Incoming ${if (callType == "video") "Video" else "Voice"} Call")
            .setContentText(callerName)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(true)
            .setTimeoutAfter(45000)
            .setSound(ringtoneUri)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .addAction(android.R.drawable.ic_menu_call, "Accept", acceptPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Decline", declinePendingIntent)
            .build()

        manager.notify(8888, notification)
    }

    private fun showMessageNotification(title: String, body: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "pulsechat_msgs_v2"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            2001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()

        manager.notify((System.currentTimeMillis() % 10000).toInt(), notification)
    }
}
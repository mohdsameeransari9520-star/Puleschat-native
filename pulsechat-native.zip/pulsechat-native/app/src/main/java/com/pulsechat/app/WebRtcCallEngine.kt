package com.pulsechat.app

import android.content.Context
import android.media.AudioManager
import com.google.firebase.database.*
import org.webrtc.*

class WebRtcCallEngine(
    private val context: Context,
    private val sessionId: String,
    private val isCaller: Boolean,
    private val isVideo: Boolean,
    private val onStatusChange: (String) -> Unit,
    private val onCallEnded: () -> Unit
) {
    private val dbRef: DatabaseReference =
        FirebaseDatabase.getInstance().reference.child("calls").child(sessionId)

    val eglBase: EglBase = EglBase.create()
    private var factory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var audioSource: AudioSource? = null
    private var localAudioTrack: AudioTrack? = null
    private var videoSource: VideoSource? = null
    private var localVideoTrack: VideoTrack? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null

    private var localRenderer: SurfaceViewRenderer? = null
    private var remoteRenderer: SurfaceViewRenderer? = null
    private var remoteVideoTrack: VideoTrack? = null

    private var statusListener: ValueEventListener? = null
    private var sdpListener: ValueEventListener? = null
    private var candidateListener: ChildEventListener? = null
    private var remoteDescriptionSet = false
    private val pendingIceCandidates = mutableListOf<IceCandidate>()
    private var isClosed = false

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun start() {
        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = isVideo
        } catch (_: Exception) {}

        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )

        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()

        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun2.l.google.com:19302").createIceServer()
        )

        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }

        peerConnection = factory?.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                when (state) {
                    PeerConnection.IceConnectionState.CONNECTED,
                    PeerConnection.IceConnectionState.COMPLETED -> onStatusChange("Connected")
                    PeerConnection.IceConnectionState.DISCONNECTED -> onStatusChange("Reconnecting...")
                    PeerConnection.IceConnectionState.FAILED -> onStatusChange("Connection Failed")
                    else -> {}
                }
            }

            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(candidate: IceCandidate?) {
                if (candidate == null || isClosed) return
                val map = mapOf(
                    "sdpMid" to candidate.sdpMid,
                    "sdpMLineIndex" to candidate.sdpMLineIndex,
                    "sdp" to candidate.sdp
                )
                val node = if (isCaller) "callerCandidates" else "calleeCandidates"
                dbRef.child(node).push().setValue(map)
            }

            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: MediaStream?) {
                val track = stream?.videoTracks?.firstOrNull()
                if (track != null) {
                    remoteVideoTrack = track
                    remoteRenderer?.let { track.addSink(it) }
                }
            }

            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {
                val track = receiver?.track()
                if (track is VideoTrack) {
                    remoteVideoTrack = track
                    remoteRenderer?.let { track.addSink(it) }
                }
            }

            override fun onTrack(transceiver: RtpTransceiver?) {
                val track = transceiver?.receiver?.track()
                if (track is VideoTrack) {
                    remoteVideoTrack = track
                    remoteRenderer?.let { track.addSink(it) }
                }
            }
        })

        // Local Audio
        audioSource = factory?.createAudioSource(MediaConstraints())
        localAudioTrack = factory?.createAudioTrack("pulse_audio", audioSource)
        localAudioTrack?.setEnabled(true)
        localAudioTrack?.let { peerConnection?.addTrack(it, listOf("pulse_stream")) }

        // Local Video (if video call)
        if (isVideo) {
            setupLocalVideo()
        }

        listenCallStatus()
        listenRemoteCandidates()

        if (isCaller) {
            dbRef.child("status").setValue("ringing")
            createOfferAndSend()
            listenForAnswer()
        } else {
            dbRef.child("status").setValue("connecting")
            listenForOfferAndAnswer()
        }
    }

    private fun setupLocalVideo() {
        try {
            val enumerator = Camera2Enumerator(context)
            val deviceName = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
                ?: enumerator.deviceNames.firstOrNull() ?: return
            videoCapturer = enumerator.createCapturer(deviceName, null)
            surfaceTextureHelper = SurfaceTextureHelper.create("PulseCaptureThread", eglBase.eglBaseContext)
            videoSource = factory?.createVideoSource(videoCapturer?.isScreencast ?: false)
            videoCapturer?.initialize(surfaceTextureHelper, context, videoSource?.capturerObserver)
            videoCapturer?.startCapture(640, 480, 24)
            localVideoTrack = factory?.createVideoTrack("pulse_video", videoSource)
            localVideoTrack?.setEnabled(true)
            localVideoTrack?.let {
                peerConnection?.addTrack(it, listOf("pulse_stream"))
                localRenderer?.let { r -> it.addSink(r) }
            }
        } catch (_: Exception) {}
    }

    fun attachLocalRenderer(renderer: SurfaceViewRenderer) {
        localRenderer = renderer
        try {
            renderer.init(eglBase.eglBaseContext, null)
            renderer.setMirror(true)
            renderer.setEnableHardwareScaler(true)
            localVideoTrack?.addSink(renderer)
        } catch (_: Exception) {}
    }

    fun attachRemoteRenderer(renderer: SurfaceViewRenderer) {
        remoteRenderer = renderer
        try {
            renderer.init(eglBase.eglBaseContext, null)
            renderer.setMirror(false)
            renderer.setEnableHardwareScaler(true)
            remoteVideoTrack?.addSink(renderer)
        } catch (_: Exception) {}
    }

    private fun createOfferAndSend() {
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (isVideo) "true" else "false"))
        }
        peerConnection?.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                if (sdp == null || isClosed) return
                peerConnection?.setLocalDescription(SimpleSdpObserver(), sdp)
                dbRef.child("offer").setValue(mapOf("type" to sdp.type.canonicalForm(), "sdp" to sdp.description))
            }
        }, constraints)
    }

    private fun listenForAnswer() {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val sdpText = snapshot.child("sdp").getValue(String::class.java) ?: return
                if (remoteDescriptionSet || isClosed) return
                val desc = SessionDescription(SessionDescription.Type.ANSWER, sdpText)
                peerConnection?.setRemoteDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        flushPendingCandidates()
                    }
                }, desc)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        sdpListener = listener
        dbRef.child("answer").addValueEventListener(listener)
    }

    private fun listenForOfferAndAnswer() {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val sdpText = snapshot.child("sdp").getValue(String::class.java) ?: return
                if (remoteDescriptionSet || isClosed) return
                val desc = SessionDescription(SessionDescription.Type.OFFER, sdpText)
                peerConnection?.setRemoteDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        flushPendingCandidates()
                        val constraints = MediaConstraints().apply {
                            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (isVideo) "true" else "false"))
                        }
                        peerConnection?.createAnswer(object : SimpleSdpObserver() {
                            override fun onCreateSuccess(answer: SessionDescription?) {
                                if (answer == null || isClosed) return
                                peerConnection?.setLocalDescription(SimpleSdpObserver(), answer)
                                dbRef.child("answer").setValue(
                                    mapOf("type" to answer.type.canonicalForm(), "sdp" to answer.description)
                                )
                            }
                        }, constraints)
                    }
                }, desc)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        sdpListener = listener
        dbRef.child("offer").addValueEventListener(listener)
    }

    private fun listenRemoteCandidates() {
        val remoteNode = if (isCaller) "calleeCandidates" else "callerCandidates"
        val listener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                if (isClosed) return
                val sdpMid = snapshot.child("sdpMid").getValue(String::class.java) ?: return
                val sdpMLineIndex = snapshot.child("sdpMLineIndex").getValue(Int::class.java) ?: 0
                val sdp = snapshot.child("sdp").getValue(String::class.java) ?: return
                val candidate = IceCandidate(sdpMid, sdpMLineIndex, sdp)
                if (remoteDescriptionSet) {
                    peerConnection?.addIceCandidate(candidate)
                } else {
                    pendingIceCandidates.add(candidate)
                }
            }
            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {}
        }
        candidateListener = listener
        dbRef.child(remoteNode).addChildEventListener(listener)
    }

    private fun flushPendingCandidates() {
        pendingIceCandidates.forEach { peerConnection?.addIceCandidate(it) }
        pendingIceCandidates.clear()
    }

    private fun listenCallStatus() {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val status = snapshot.getValue(String::class.java) ?: return
                if (status == "ended" || status == "declined") {
                    onStatusChange(if (status == "declined") "Declined" else "Ended")
                    onCallEnded()
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        statusListener = listener
        dbRef.child("status").addValueEventListener(listener)
    }

    fun setMicMuted(muted: Boolean) {
        localAudioTrack?.setEnabled(!muted)
    }

    fun setCameraOff(off: Boolean) {
        localVideoTrack?.setEnabled(!off)
    }

    fun setSpeakerOn(on: Boolean) {
        try { audioManager.isSpeakerphoneOn = on } catch (_: Exception) {}
    }

    fun switchCamera() {
        try { videoCapturer?.switchCamera(null) } catch (_: Exception) {}
    }

    fun end(notifyRemote: Boolean = true) {
        if (isClosed) return
        isClosed = true
        if (notifyRemote) {
            try { dbRef.child("status").setValue("ended") } catch (_: Exception) {}
        }
        try { statusListener?.let { dbRef.child("status").removeEventListener(it) } } catch (_: Exception) {}
        try {
            val sdpNode = if (isCaller) "answer" else "offer"
            sdpListener?.let { dbRef.child(sdpNode).removeEventListener(it) }
        } catch (_: Exception) {}
        try {
            val candNode = if (isCaller) "calleeCandidates" else "callerCandidates"
            candidateListener?.let { dbRef.child(candNode).removeEventListener(it) }
        } catch (_: Exception) {}

        try { videoCapturer?.stopCapture() } catch (_: Exception) {}
        try { videoCapturer?.dispose() } catch (_: Exception) {}
        try { surfaceTextureHelper?.dispose() } catch (_: Exception) {}
        try { localVideoTrack?.dispose() } catch (_: Exception) {}
        try { localAudioTrack?.dispose() } catch (_: Exception) {}
        try { videoSource?.dispose() } catch (_: Exception) {}
        try { audioSource?.dispose() } catch (_: Exception) {}
        try { peerConnection?.close() } catch (_: Exception) {}
        try { peerConnection?.dispose() } catch (_: Exception) {}
        try { localRenderer?.release() } catch (_: Exception) {}
        try { remoteRenderer?.release() } catch (_: Exception) {}
        try { factory?.dispose() } catch (_: Exception) {}
        try { eglBase.release() } catch (_: Exception) {}
        try {
            audioManager.mode = AudioManager.MODE_NORMAL
            audioManager.isSpeakerphoneOn = false
        } catch (_: Exception) {}
    }

    open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(sdp: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetFailure(error: String?) {}
    }
}